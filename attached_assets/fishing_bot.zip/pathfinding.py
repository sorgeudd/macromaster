import numpy as np
import logging
import heapq
from typing import List, Tuple, Dict, Optional
from dataclasses import dataclass

logger = logging.getLogger(__name__)

@dataclass
class Node:
    x: int
    y: int
    g_cost: float = float('inf')  # Cost from start to this node
    h_cost: float = float('inf')  # Estimated cost from this node to end
    parent: Optional['Node'] = None

    @property
    def f_cost(self) -> float:
        """Total estimated cost through this node"""
        return self.g_cost + self.h_cost

    def __lt__(self, other):
        return self.f_cost < other.f_cost

class PathFinder:
    def __init__(self, grid_size: int = 32):
        self.grid_size = grid_size
        self.obstacles: List[Tuple[int, int]] = []
        self.test_mode = False
        
        # Movement directions (8-directional)
        self.directions = [
            (-1, -1), (0, -1), (1, -1),
            (-1, 0),           (1, 0),
            (-1, 1),  (0, 1),  (1, 1)
        ]
        
        logger.info(f"PathFinder initialized with grid size: {grid_size}")

    def screen_to_grid(self, x: float, y: float) -> Tuple[int, int]:
        """Convert screen coordinates to grid coordinates"""
        grid_x = int(x / self.grid_size)
        grid_y = int(y / self.grid_size)
        return (grid_x, grid_y)

    def grid_to_screen(self, grid_x: int, grid_y: int) -> Tuple[float, float]:
        """Convert grid coordinates to screen coordinates (center of grid cell)"""
        screen_x = (grid_x + 0.5) * self.grid_size
        screen_y = (grid_y + 0.5) * self.grid_size
        return (screen_x, screen_y)

    def add_obstacle(self, x: float, y: float):
        """Add an obstacle at the given screen coordinates"""
        grid_pos = self.screen_to_grid(x, y)
        if grid_pos not in self.obstacles:
            self.obstacles.append(grid_pos)
            logger.debug(f"Added obstacle at grid position {grid_pos}")

    def clear_obstacles(self):
        """Clear all obstacles"""
        self.obstacles = []
        logger.debug("Cleared all obstacles")

    def calculate_path(self, start_x: float, start_y: float, 
                      end_x: float, end_y: float) -> List[Tuple[float, float]]:
        """
        Calculate path from start to end position using A* pathfinding
        Returns list of screen coordinates forming the path
        """
        # Convert to grid coordinates
        start_grid = self.screen_to_grid(start_x, start_y)
        end_grid = self.screen_to_grid(end_x, end_y)

        # Initialize nodes
        start_node = Node(start_grid[0], start_grid[1], g_cost=0)
        start_node.h_cost = self._calculate_heuristic(start_grid, end_grid)
        end_node = Node(end_grid[0], end_grid[1])

        # Initialize open and closed sets
        open_set = []
        heapq.heappush(open_set, start_node)
        closed_set: Dict[Tuple[int, int], Node] = {}

        while open_set:
            current = heapq.heappop(open_set)
            
            # Check if we reached the end
            if (current.x, current.y) == (end_node.x, end_node.y):
                path = self._reconstruct_path(current)
                logger.info(f"Path found with {len(path)} nodes")
                return path

            # Add to closed set
            closed_set[(current.x, current.y)] = current

            # Check neighbors
            for dx, dy in self.directions:
                neighbor_pos = (current.x + dx, current.y + dy)
                
                # Skip if neighbor is in closed set or is obstacle
                if neighbor_pos in closed_set or neighbor_pos in self.obstacles:
                    continue

                # Calculate new costs
                new_g_cost = current.g_cost + (1.4 if dx * dy != 0 else 1.0)
                
                neighbor = Node(neighbor_pos[0], neighbor_pos[1])
                neighbor.g_cost = new_g_cost
                neighbor.h_cost = self._calculate_heuristic(neighbor_pos, end_grid)
                neighbor.parent = current

                # Add to open set if not already there or if better path found
                if neighbor not in open_set:
                    heapq.heappush(open_set, neighbor)

        logger.warning("No path found")
        return []

    def _calculate_heuristic(self, pos1: Tuple[int, int], pos2: Tuple[int, int]) -> float:
        """Calculate heuristic cost between two positions using diagonal distance"""
        dx = abs(pos1[0] - pos2[0])
        dy = abs(pos1[1] - pos2[1])
        return max(dx, dy) + 0.4 * min(dx, dy)

    def _reconstruct_path(self, end_node: Node) -> List[Tuple[float, float]]:
        """Reconstruct path from end node to start node"""
        path = []
        current = end_node
        
        while current:
            screen_pos = self.grid_to_screen(current.x, current.y)
            path.append(screen_pos)
            current = current.parent
            
        return list(reversed(path))  # Reverse to get start->end order

    def smooth_path(self, path: List[Tuple[float, float]], 
                   smoothing_factor: float = 0.5) -> List[Tuple[float, float]]:
        """Apply path smoothing to reduce zigzag movement"""
        if len(path) <= 2:
            return path
            
        smoothed = list(path)
        change = True
        while change:
            change = False
            for i in range(1, len(smoothed) - 1):
                old_x, old_y = smoothed[i]
                new_x = smoothed[i-1][0] * smoothing_factor + \
                       smoothed[i+1][0] * smoothing_factor + \
                       old_x * (1 - 2 * smoothing_factor)
                new_y = smoothed[i-1][1] * smoothing_factor + \
                       smoothed[i+1][1] * smoothing_factor + \
                       old_y * (1 - 2 * smoothing_factor)
                
                if abs(new_x - old_x) > 0.1 or abs(new_y - old_y) > 0.1:
                    smoothed[i] = (new_x, new_y)
                    change = True
                    
        return smoothed
