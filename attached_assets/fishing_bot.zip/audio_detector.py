import pyaudio
import numpy as np
import wave
import threading
import time
import logging
import platform
from array import array
import random
import os
from datetime import datetime

logger = logging.getLogger(__name__)

class AudioDetector:
    def __init__(self):
        self.CHUNK = 1024
        self.FORMAT = pyaudio.paFloat32
        self.CHANNELS = 1
        self.RATE = 44100
        self.THRESHOLD = 0.1
        self.recording = False
        self.sample_sound = None
        self.callback = None
        self.test_mode = platform.system() != 'Windows'

        # New attributes for recording info
        self.last_recording_info = None
        self.recordings_dir = "recorded_samples"

        # Create recordings directory if it doesn't exist
        if not os.path.exists(self.recordings_dir):
            os.makedirs(self.recordings_dir)

        if self.test_mode:
            logger.info("Audio detector initializing in test mode")
            self.p = None
            self._setup_test_mode()
        else:
            try:
                self.p = pyaudio.PyAudio()
                logger.info("Audio system initialized successfully")
            except Exception as e:
                logger.error(f"Failed to initialize audio system: {e}")
                self.p = None
                self.test_mode = True
                self._setup_test_mode()

    def _setup_test_mode(self):
        """
        Set up test mode configurations and initialize mock audio system.
        """
        self.sample_sound = np.zeros(self.CHUNK, dtype=np.float32)  # Mock sample
        self.last_bite_time = time.time()  # Track last bite time for more natural intervals
        logger.info("Test mode: Audio detector mock initialized")

    def start_listening(self, callback):
        """Start listening for fish bite sounds"""
        if self.test_mode:
            logger.info("Test mode: Started mock audio listening")
            self.callback = callback
            self.recording = True
            logger.debug("Test mode: Starting mock audio stream thread")
            threading.Thread(target=self._mock_audio_stream, daemon=True).start()
            return

        if self.p is None:
            logger.error("Audio system not initialized")
            return

        try:
            self.callback = callback
            self.recording = True
            threading.Thread(target=self._audio_stream, daemon=True).start()
            logger.info("Started audio listening")
        except Exception as e:
            logger.error(f"Error starting audio listener: {e}")
            self.recording = False

    def stop_listening(self):
        """Stop listening for sounds"""
        try:
            self.recording = False
            logger.info("Stopped audio listening")
        except Exception as e:
            logger.error(f"Error stopping audio listener: {e}")

    def record_sample(self, duration=2):
        """Record a sample sound for matching"""
        if self.test_mode:
            logger.debug("Test mode: Generating mock sample sound")
            self.sample_sound = np.random.normal(0, 0.1, self.CHUNK).astype(np.float32)

            # Save mock recording info
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = os.path.join(self.recordings_dir, f"test_sample_{timestamp}.wav")
            self.last_recording_info = {
                'duration': duration,
                'max_volume': np.max(np.abs(self.sample_sound)),
                'filepath': filepath,
                'timestamp': timestamp
            }

            # Save mock sample to file
            self._save_sample_to_file(self.sample_sound, filepath)
            logger.info("Test mode: Mock sample recorded successfully")
            return

        if self.p is None:
            logger.error("Audio system not initialized")
            return

        try:
            frames = []
            stream = self.p.open(
                format=self.FORMAT,
                channels=self.CHANNELS,
                rate=self.RATE,
                input=True,
                frames_per_buffer=self.CHUNK
            )

            logger.info("Recording sample...")
            for _ in range(0, int(self.RATE / self.CHUNK * duration)):
                data = stream.read(self.CHUNK, exception_on_overflow=False)
                frames.append(np.frombuffer(data, dtype=np.float32))

            stream.stop_stream()
            stream.close()

            # Combine all frames
            self.sample_sound = np.concatenate(frames)

            # Trim silence
            self.sample_sound = self._trim_silence(self.sample_sound)

            # Save recording info
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = os.path.join(self.recordings_dir, f"sample_{timestamp}.wav")

            self.last_recording_info = {
                'duration': len(self.sample_sound) / self.RATE,
                'max_volume': np.max(np.abs(self.sample_sound)),
                'filepath': filepath,
                'timestamp': timestamp
            }

            # Save sample to file
            self._save_sample_to_file(self.sample_sound, filepath)
            logger.info("Sample recorded successfully")

        except Exception as e:
            logger.error(f"Error recording sample: {e}")
            self.sample_sound = None
            self.last_recording_info = None

    def _trim_silence(self, audio_data, threshold=0.02):
        """Trim silence from beginning and end of audio data"""
        try:
            # Convert to absolute values
            abs_audio = np.abs(audio_data)

            # Find where audio exceeds threshold
            mask = abs_audio > threshold

            if not np.any(mask):
                return audio_data  # Return original if no sound found

            # Find first and last non-silent points
            start = np.argmax(mask)
            end = len(mask) - np.argmax(mask[::-1])

            # Add small buffer
            buffer_size = int(0.1 * self.RATE)  # 0.1 second buffer
            start = max(0, start - buffer_size)
            end = min(len(audio_data), end + buffer_size)

            return audio_data[start:end]
        except Exception as e:
            logger.error(f"Error trimming silence: {e}")
            return audio_data

    def _save_sample_to_file(self, audio_data, filepath):
        """Save audio sample to WAV file"""
        try:
            with wave.open(filepath, 'wb') as wf:
                wf.setnchannels(self.CHANNELS)
                wf.setsampwidth(4)  # 32-bit float
                wf.setframerate(self.RATE)
                wf.writeframes(audio_data.tobytes())
            logger.info(f"Saved audio sample to {filepath}")
        except Exception as e:
            logger.error(f"Error saving audio sample: {e}")

    def get_sample_info(self):
        """Get information about the last recorded sample"""
        return self.last_recording_info

    def get_recorded_samples(self):
        """Get list of all recorded samples"""
        try:
            if not os.path.exists(self.recordings_dir):
                return []

            samples = []
            for filename in os.listdir(self.recordings_dir):
                if filename.endswith('.wav'):
                    filepath = os.path.join(self.recordings_dir, filename)
                    timestamp = filename.split('_')[1].split('.')[0]
                    samples.append({
                        'filename': filename,
                        'filepath': filepath,
                        'timestamp': timestamp
                    })
            return sorted(samples, key=lambda x: x['timestamp'], reverse=True)
        except Exception as e:
            logger.error(f"Error getting recorded samples: {e}")
            return []

    def _mock_audio_stream(self):
        """
        Simulate audio stream in test mode.

        Simulation Behavior:
        - Runs in a separate thread
        - Generates periodic fish bite events (10% chance every 1-3 seconds)
        - Provides continuous feedback through logging
        """
        logger.info("Test mode: Started mock audio stream")
        cycle_count = 0
        while self.recording:
            cycle_count += 1
            logger.debug(f"Test mode: Audio stream cycle {cycle_count}")
            # Random delay between 1-3 seconds for more realistic timing
            time.sleep(random.uniform(1.0, 3.0))
            if np.random.random() < 0.1:  # Reduced chance for more realistic simulation
                if self.callback:
                    current_time = time.time()
                    time_since_last = current_time - self.last_bite_time
                    logger.info(f"Test mode: Simulated fish bite detected (Time since last: {time_since_last:.1f}s)")
                    self.last_bite_time = current_time
                    self.callback()
                    logger.debug("Test mode: Fish bite callback executed")

    def _audio_stream(self):
        """Continuous audio stream monitoring"""
        if self.p is None:
            return

        try:
            stream = self.p.open(
                format=self.FORMAT,
                channels=self.CHANNELS,
                rate=self.RATE,
                input=True,
                frames_per_buffer=self.CHUNK
            )

            logger.info("Audio stream started")
            while self.recording:
                try:
                    data = np.frombuffer(
                        stream.read(self.CHUNK, exception_on_overflow=False),
                        dtype=np.float32
                    )

                    if self.sample_sound is not None and self._match_sound(data):
                        if self.callback:
                            logger.info("Fish bite detected!")
                            self.callback()

                except Exception as e:
                    logger.error(f"Error in audio stream: {e}")
                    time.sleep(0.1)  # Prevent tight loop on error

            stream.stop_stream()
            stream.close()
            logger.info("Audio stream closed")

        except Exception as e:
            logger.error(f"Error setting up audio stream: {e}")
            self.recording = False

    def _match_sound(self, current_audio):
        """Compare current audio with sample using improved matching algorithm"""
        try:
            if self.sample_sound is None:
                return False

            if len(current_audio) != len(self.sample_sound):
                return False

            # Use normalized cross-correlation for better matching
            current_normalized = (current_audio - np.mean(current_audio)) / np.std(current_audio)
            sample_normalized = (self.sample_sound - np.mean(self.sample_sound)) / np.std(self.sample_sound)

            # Calculate correlation coefficient
            correlation = np.correlate(current_normalized, sample_normalized)[0] / len(current_audio)

            # More lenient threshold for better detection
            return correlation > self.THRESHOLD

        except Exception as e:
            logger.error(f"Error matching sound: {e}")
            return False