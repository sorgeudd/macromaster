import logging
import time
from gameplay_learner import GameplayLearner
from ai_inference import AIInference
import os

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def test_learning_system():
    """
    Test the AI-enhanced learning system by simulating fishing events
    and demonstrating how predictions improve over time.
    """
    learner = GameplayLearner()
    logger.info("Starting learning system test...")

    # Simulate a series of fishing attempts
    for i in range(5):
        # Simulate cast -> bite -> hook sequence
        cast_time = time.time()
        time.sleep(0.5)  # Simulate waiting for bite
        bite_time = time.time()
        time.sleep(0.2)  # Simulate hook timing
        hook_time = time.time()
        
        # Record the attempt
        success = True if i > 1 else False  # Simulate improving success rate
        learner.record_fishing_attempt(cast_time, bite_time, hook_time, success)
        
        # Get current stats
        stats = learner.get_learning_stats()
        logger.info(f"Attempt {i+1} stats: {stats}")
        
        # Simulate minigame actions
        for _ in range(3):
            position = 0.5  # Center position
            timing = time.time()
            learner.record_minigame_action(position, timing, True)
        
        # Get optimal click threshold
        threshold = learner.get_optimal_click_threshold()
        logger.info(f"Optimal click threshold: {threshold}")
        
        time.sleep(1)  # Pause between attempts

def main():
    """
    Main test function that demonstrates the learning system
    with and without API token.
    """
    logger.info("Testing fishing bot learning system")
    
    # First test without API token (fallback mode)
    if "HUGGINGFACE_API_TOKEN" in os.environ:
        del os.environ["HUGGINGFACE_API_TOKEN"]
    logger.info("Testing without API token (fallback mode)...")
    test_learning_system()
    
    # Test with API token if available
    api_token = os.environ.get("HUGGINGFACE_API_TOKEN")
    if api_token:
        logger.info("Testing with API token...")
        test_learning_system()
    else:
        logger.info(
            "No Hugging Face API token found. To enable AI-enhanced learning:\n"
            "1. Get an API token from https://huggingface.co/settings/tokens\n"
            "2. Set the HUGGINGFACE_API_TOKEN environment variable\n"
            "3. Restart the bot"
        )

if __name__ == "__main__":
    main()
