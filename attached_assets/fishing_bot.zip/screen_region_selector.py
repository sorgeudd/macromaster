import tkinter as tk
from tkinter import ttk, messagebox
import platform
import logging
import os
import time
import ctypes

logger = logging.getLogger(__name__)

class ScreenRegionSelector:
    def __init__(self, callback=None):
        self.start_x = None
        self.start_y = None
        self.current_rectangle = None
        self.dimension_text = None
        self.callback = callback
        self.test_mode = platform.system() != 'Windows'
        self.is_selecting = False

        if self.test_mode:
            logger.info("Screen region selector initialized in test mode")
            return

        # Set up DPI awareness first
        if platform.system() == 'Windows':
            try:
                ctypes.windll.shcore.SetProcessDpiAwareness(2)  # PROCESS_PER_MONITOR_DPI_AWARE
            except Exception as e:
                try:
                    ctypes.windll.user32.SetProcessDPIAware()
                except Exception as e:
                    logger.warning(f"Could not set DPI awareness: {e}")

        # Initialize root window
        self.root = tk.Tk()
        self.root.title("Select Game Window")
        self.root.attributes('-alpha', 0.3)
        self.root.attributes('-fullscreen', True)
        self.root.attributes('-topmost', True)

        # Create canvas
        self.canvas = tk.Canvas(self.root, highlightthickness=0)
        self.canvas.pack(fill='both', expand=True)

        # Create overlay
        self.overlay = self.canvas.create_rectangle(
            0, 0, self.root.winfo_screenwidth(), self.root.winfo_screenheight(),
            fill='gray', stipple='gray50'
        )

        # Add instruction text
        self.instruction_text = self.canvas.create_text(
            self.root.winfo_screenwidth() // 2,
            50,
            text="Click and drag to select game window area\nPress Escape to cancel",
            fill="white",
            font=("Arial", 16, "bold")
        )

        # Bind events
        self.canvas.bind('<Button-1>', self.start_rectangle)
        self.canvas.bind('<B1-Motion>', self.draw_rectangle)
        self.canvas.bind('<ButtonRelease-1>', self.end_rectangle)
        self.root.bind('<Escape>', lambda e: self.cancel_selection())

    def start_rectangle(self, event):
        """Start drawing rectangle"""
        if not self.is_selecting:
            self.is_selecting = True
            self.start_x = event.x
            self.start_y = event.y

            # Create initial rectangle
            self.current_rectangle = self.canvas.create_rectangle(
                self.start_x, self.start_y,
                self.start_x, self.start_y,
                outline='red',
                width=2
            )

            # Create dimension text
            self.dimension_text = self.canvas.create_text(
                event.x, event.y - 20,
                text="0 x 0",
                fill="white",
                font=("Arial", 12)
            )

    def draw_rectangle(self, event):
        """Update rectangle while dragging"""
        if self.is_selecting and self.current_rectangle:
            # Update rectangle
            self.canvas.coords(self.current_rectangle,
                self.start_x, self.start_y, event.x, event.y)

            # Update dimension text
            width = abs(event.x - self.start_x)
            height = abs(event.y - self.start_y)
            self.canvas.itemconfig(self.dimension_text, text=f"{width} x {height}")
            self.canvas.coords(self.dimension_text,
                min(event.x, self.start_x) + width/2,
                min(event.y, self.start_y) - 20)

    def end_rectangle(self, event):
        """Finish rectangle selection"""
        if self.is_selecting and self.callback:
            # Calculate coordinates
            x1 = min(self.start_x, event.x)
            y1 = min(self.start_y, event.y)
            x2 = max(self.start_x, event.x)
            y2 = max(self.start_y, event.y)

            # Return selection and close window
            self.callback((int(x1), int(y1), int(x2), int(y2)))
            self.root.destroy()

        self.is_selecting = False

    def cancel_selection(self):
        """Cancel the selection process"""
        self.root.destroy()

    def get_region(self):
        """Start the region selection process"""
        if self.test_mode:
            logger.info("Test mode: Returning default region (0, 0, 800, 600)")
            return (0, 0, 800, 600)

        self.root.mainloop()