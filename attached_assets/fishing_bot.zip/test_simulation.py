import unittest
import numpy as np
import time
from audio_detector import AudioDetector
from screen_analyzer import ScreenAnalyzer
from game_controller import GameController
from gui import FishingBotGUI

class TestFishingSimulation(unittest.TestCase):
    def setUp(self):
        """Initialize components for testing"""
        self.audio_detector = AudioDetector()
        self.screen_analyzer = ScreenAnalyzer()
        self.game_controller = GameController()

    def test_audio_detection_timing(self):
        """Test fish bite detection timing patterns"""
        bite_times = []

        def on_bite():
            bite_times.append(time.time())

        self.audio_detector.start_listening(on_bite)
        time.sleep(10)  # Record 10 seconds of bites
        self.audio_detector.stop_listening()

        # Check intervals between bites
        if len(bite_times) >= 2:
            intervals = np.diff(bite_times)
            self.assertTrue(all(1.0 <= interval <= 3.0 for interval in intervals),
                          "Fish bite intervals should be between 1-3 seconds")

    def test_fishing_spot_movement(self):
        """Test fishing spot movement patterns"""
        positions = []
        screen = self.screen_analyzer.capture_screen()

        # Record spot positions with proper time intervals
        for _ in range(5):  # Reduced from 10 to 5 samples
            self.screen_analyzer.detect_fishing_spots(screen)
            if len(self.screen_analyzer.fishing_spots) > 0:
                pos = self.screen_analyzer.fishing_spots[0][:2].copy()
                positions.append(pos)
            time.sleep(0.2)  # Increased interval for more stable measurements

        if len(positions) >= 2:
            positions = np.array(positions)
            # Calculate velocities between consecutive positions
            time_step = 0.2  # Match the sleep interval
            velocities = np.diff(positions, axis=0) / time_step
            speeds = np.linalg.norm(velocities, axis=1)

            max_allowed_speed = self.screen_analyzer.max_velocity
            for i, speed in enumerate(speeds):
                self.assertLessEqual(
                    speed, max_allowed_speed,
                    f"Speed {speed:.2f} at step {i} exceeds maximum {max_allowed_speed}"
                )

    def test_minigame_bar_behavior(self):
        """Test minigame bar movement patterns"""
        positions = []
        screen = self.screen_analyzer.capture_screen()

        # Record bar positions over time
        for _ in range(20):
            pos = self.screen_analyzer.detect_minigame_bar(screen)
            if pos is not None:
                positions.append(pos)
            time.sleep(0.1)

        # Verify bar stays within bounds
        self.assertTrue(all(0.0 <= pos <= 1.0 for pos in positions),
                       "Minigame bar should stay within bounds")

        # Verify smooth movement
        if len(positions) >= 2:
            changes = np.diff(positions)
            self.assertTrue(all(abs(change) <= 0.1 for change in changes),
                          "Bar movement should be smooth")

    def test_game_controller_actions(self):
        """Test game controller action simulation"""
        # Test casting
        result = self.game_controller.cast_line(500, 300, 1.0)
        self.assertTrue(result, "Cast line action should succeed in test mode")

        # Test minigame handling
        self.game_controller.in_minigame = True
        result = self.game_controller.handle_minigame(0.15)  # Test low position
        self.assertTrue(result, "Minigame handling should succeed in test mode")

        result = self.game_controller.handle_minigame(0.85)  # Test high position
        self.assertTrue(result, "Minigame handling should succeed in test mode")

if __name__ == '__main__':
    unittest.main()