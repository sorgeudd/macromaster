#!/bin/bash

echo "Checking Python installation..."

# Check if Python 3 is installed
if command -v python3 &>/dev/null; then
    echo "Python 3 found, installing required packages..."
    python3 -m pip install keyboard numpy opencv-python scikit-learn
elif command -v python &>/dev/null; then
    echo "Python found, checking version..."
    if python --version | grep -q "Python 3"; then
        echo "Python 3 found, installing required packages..."
        python -m pip install keyboard numpy opencv-python scikit-learn
    else
        echo "Error: Python 3 is required but older version was found"
        echo "Please install Python 3 from your package manager or https://www.python.org/downloads/"
        exit 1
    fi
else
    echo "Error: Python is not installed"
    echo "Please install Python 3 from your package manager or https://www.python.org/downloads/"
    exit 1
fi

echo ""
echo "Installation complete! You can now run: python3 main.py"