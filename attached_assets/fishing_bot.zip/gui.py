"""Import pyautogui conditionally to handle environments without X11"""
import tkinter as tk
from tkinter import ttk, messagebox
import json
from config import Config
import threading
import logging
import platform
import os
import sys
import time
import subprocess
from screen_region_selector import ScreenRegionSelector

# Add explicit import for pyautogui
try:
    import pyautogui
except ImportError:
    pyautogui = None
    logging.warning("pyautogui not available, some features will be limited")

logger = logging.getLogger(__name__)


class SettingsPanel(tk.Toplevel):
    def __init__(self, parent, config):
        super().__init__(parent)
        self.title("Bot Settings")
        self.config = config
        self.parent = parent

        # Dictionary to store all setting widgets
        self.setting_widgets = {}

        # Create notebook for tabbed interface
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(expand=True, fill='both', padx=5, pady=5)

        # Create tabs for different setting categories
        self.create_audio_tab()
        self.create_fishing_tab()
        self.create_minigame_tab()
        self.create_movement_tab()
        self.create_combat_tab()

        # Add bottom buttons
        self.create_bottom_buttons()

        logger.info("Settings panel initialized")

    def create_audio_tab(self):
        frame = ttk.Frame(self.notebook)
        self.notebook.add(frame, text='Audio')

        settings = self.config.get_category('audio')
        widgets = {}
        row = 0

        # Audio threshold
        ttk.Label(frame, text="Detection Threshold:").grid(row=row, column=0, padx=5, pady=5)
        threshold = ttk.Scale(frame, from_=0.01, to=1.0, orient='horizontal')
        threshold.set(settings['threshold'])
        threshold.grid(row=row, column=1, padx=5, pady=5)
        widgets['threshold'] = threshold

        row += 1
        # Sample rate
        ttk.Label(frame, text="Sample Rate:").grid(row=row, column=0, padx=5, pady=5)
        rates = ['22050', '44100', '48000']  # Convert to strings for Combobox
        rate = ttk.Combobox(frame, values=rates)
        rate.set(str(settings['sample_rate']))
        rate.grid(row=row, column=1, padx=5, pady=5)
        widgets['sample_rate'] = rate

        self.setting_widgets['audio'] = widgets

    def create_fishing_tab(self):
        frame = ttk.Frame(self.notebook)
        self.notebook.add(frame, text='Fishing')

        settings = self.config.get_category('fishing_spot')
        widgets = {}
        row = 0

        # Movement speed
        ttk.Label(frame, text="Movement Speed:").grid(row=row, column=0, padx=5, pady=5)
        speed = ttk.Scale(frame, from_=0.1, to=2.0, orient='horizontal')
        speed.set(settings['movement_speed'])
        speed.grid(row=row, column=1, padx=5, pady=5)
        widgets['movement_speed'] = speed

        self.setting_widgets['fishing_spot'] = widgets

    def create_minigame_tab(self):
        frame = ttk.Frame(self.notebook)
        self.notebook.add(frame, text='Minigame')

        settings = self.config.get_category('minigame')
        widgets = {}
        row = 0

        # Reaction speed
        ttk.Label(frame, text="Reaction Speed:").grid(row=row, column=0, padx=5, pady=5)
        speed = ttk.Scale(frame, from_=0.1, to=2.0, orient='horizontal')
        speed.set(settings['reaction_speed'])
        speed.grid(row=row, column=1, padx=5, pady=5)
        widgets['reaction_speed'] = speed

        row += 1
        # Bar boundaries
        ttk.Label(frame, text="Left Boundary:").grid(row=row, column=0, padx=5, pady=5)
        left = ttk.Scale(frame, from_=0.0, to=0.5, orient='horizontal')
        left.set(settings['bar_left_boundary'])
        left.grid(row=row, column=1, padx=5, pady=5)
        widgets['bar_left_boundary'] = left

        row += 1
        ttk.Label(frame, text="Right Boundary:").grid(row=row, column=0, padx=5, pady=5)
        right = ttk.Scale(frame, from_=0.5, to=1.0, orient='horizontal')
        right.set(settings['bar_right_boundary'])
        right.grid(row=row, column=1, padx=5, pady=5)
        widgets['bar_right_boundary'] = right

        self.setting_widgets['minigame'] = widgets

    def create_movement_tab(self):
        frame = ttk.Frame(self.notebook)
        self.notebook.add(frame, text='Movement')

        settings = self.config.get_category('movement')
        widgets = {}
        row = 0

        # Path smoothing
        ttk.Label(frame, text="Path Smoothing:").grid(row=row, column=0, padx=5, pady=5)
        smooth = ttk.Scale(frame, from_=0.1, to=1.0, orient='horizontal')
        smooth.set(settings['path_smoothing'])
        smooth.grid(row=row, column=1, padx=5, pady=5)
        widgets['path_smoothing'] = smooth

        row += 1
        # Random variance
        ttk.Label(frame, text="Random Variance:").grid(row=row, column=0, padx=5, pady=5)
        variance = ttk.Scale(frame, from_=0.0, to=0.5, orient='horizontal')
        variance.set(settings['random_variance'])
        variance.grid(row=row, column=1, padx=5, pady=5)
        widgets['random_variance'] = variance

        self.setting_widgets['movement'] = widgets

    def create_combat_tab(self):
        frame = ttk.Frame(self.notebook)
        self.notebook.add(frame, text='Combat')

        settings = self.config.get_category('combat')
        widgets = {}
        row = 0

        # Auto-heal threshold
        ttk.Label(frame, text="Auto-heal Threshold:").grid(row=row, column=0, padx=5, pady=5)
        threshold = ttk.Scale(frame, from_=0.1, to=1.0, orient='horizontal')
        threshold.set(settings['auto_heal_threshold'])
        threshold.grid(row=row, column=1, padx=5, pady=5)
        widgets['auto_heal_threshold'] = threshold

        row += 1
        # Skill delay
        ttk.Label(frame, text="Skill Delay:").grid(row=row, column=0, padx=5, pady=5)
        delay = ttk.Scale(frame, from_=0.05, to=1.0, orient='horizontal')
        delay.set(settings['skill_delay'])
        delay.grid(row=row, column=1, padx=5, pady=5)
        widgets['skill_delay'] = delay

        self.setting_widgets['combat'] = widgets

    def create_bottom_buttons(self):
        button_frame = ttk.Frame(self)
        button_frame.pack(fill='x', padx=5, pady=5)

        ttk.Button(button_frame, text="Save", command=self.save_settings).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Reset to Defaults", command=self.reset_settings).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Close", command=self.destroy).pack(side='right', padx=5)

    def save_settings(self):
        """Save all settings from widgets to config"""
        try:
            # Update each category's settings
            for category, widgets in self.setting_widgets.items():
                new_values = {}
                for setting_name, widget in widgets.items():
                    if isinstance(widget, ttk.Scale):
                        new_values[setting_name] = widget.get()
                    elif isinstance(widget, ttk.Combobox):
                        # Convert string to int for numeric settings
                        try:
                            new_values[setting_name] = int(widget.get())
                        except ValueError:
                            new_values[setting_name] = widget.get()

                # Update category in config
                self.config.update_category(category, new_values)

            logger.info("Settings saved successfully")
            messagebox.showinfo("Success", "Settings saved successfully!")
            self.destroy()
        except Exception as e:
            logger.error(f"Error saving settings: {e}")
            messagebox.showerror("Error", f"Failed to save settings: {str(e)}")

    def reset_settings(self):
        """Reset all settings to defaults"""
        if messagebox.askyesno("Reset Settings", "Are you sure you want to reset all settings to defaults?"):
            try:
                self.config.reset_to_defaults()
                logger.info("Settings reset to defaults")
                messagebox.showinfo("Success", "Settings reset to defaults!")
                self.destroy()
            except Exception as e:
                logger.error(f"Error resetting settings: {e}")
                messagebox.showerror("Error", f"Failed to reset settings: {str(e)}")


class MockSettingsPanel:
    def __init__(self, parent, config):
        self.config = config
        logger.info("Test mode: Mock settings panel initialized")
        self.simulate_settings_interaction()

    def simulate_settings_interaction(self):
        """Simulate settings interaction in test mode"""
        try:
            # Simulate changing some settings
            new_audio_settings = {
                'threshold': 0.15,
                'sample_rate': 44100
            }
            self.config.update_category('audio', new_audio_settings)
            logger.info("Test mode: Simulated audio settings update")

            new_minigame_settings = {
                'reaction_speed': 1.2,
                'bar_left_boundary': 0.25
            }
            self.config.update_category('minigame', new_minigame_settings)
            logger.info("Test mode: Simulated minigame settings update")

            logger.info("Test mode: Settings panel simulation complete")
        except Exception as e:
            logger.error(f"Error in settings simulation: {e}")


class FishingBotGUI:
    def __init__(self, audio_detector, screen_analyzer, game_controller):
        self.test_mode = platform.system() != 'Windows'
        self.audio_detector = audio_detector
        self.screen_analyzer = screen_analyzer
        self.game_controller = game_controller
        self.config = Config()
        self.is_windows = platform.system() == 'Windows'
        self.is_running = False
        self.window_check_interval = 5.0  # Check window every 5 seconds
        self.last_window_check = 0

        # Try to register hotkey only on Windows
        if self.is_windows:
            try:
                import keyboard
                keyboard.on_press_key('F6', lambda _: self.emergency_stop())
                logger.info("Emergency stop hotkey (F6) registered")
            except Exception as e:
                logger.warning(f"Could not register hotkey: {e}")

        if self.test_mode:
            logger.info("GUI initializing in test mode")
            self._setup_test_mode()
        else:
            self._init_gui()

    def check_game_window(self):
        """Periodically check if game window is still available"""
        current_time = time.time()
        if current_time - self.last_window_check >= self.window_check_interval:
            self.last_window_check = current_time
            if not self.test_mode and not self.screen_analyzer._find_game_window():
                logger.warning("Game window not found during periodic check")
                if not self.test_mode:
                    self.status_label["text"] = "Game window not found! Please make sure the game is visible."
                    return False
            return True

    def emergency_stop(self):
        """Emergency stop function triggered by hotkey or button"""
        try:
            logger.info("Emergency stop triggered")
            self.is_running = False
            self.stop_bot()
            if not self.test_mode:
                # Make the emergency stop more visible
                self.status_label["text"] = "EMERGENCY STOP ACTIVATED"
                self.emergency_button["style"] = "EmergencyActive.TButton"
                messagebox.showinfo("Bot Stopped", "Bot stopped by emergency stop (F6)")

                # Reset button style after a short delay
                self.root.after(2000, lambda: self.emergency_button.configure(style="Emergency.TButton"))
        except Exception as e:
            logger.error(f"Error in emergency stop: {e}")

    def stop_bot(self):
        """Enhanced stop bot function"""
        try:
            self.is_running = False  # Set flag to stop screen monitoring thread
            self.start_button["text"] = "Start Bot"
            self.status_label["text"] = "Idle"
            self.audio_detector.stop_listening()
            logger.info("Bot stopped successfully")
            if not self.test_mode:
                messagebox.showinfo("Success", "Bot stopped successfully!")
        except Exception as e:
            logger.error(f"Error stopping bot: {e}")
            self.handle_error(Exception, e, None)

    def record_sound(self):
        """Enhanced record sound function with feedback"""
        try:
            logger.debug("Starting sound recording")
            self.status_label["text"] = "Recording sound..."
            self.record_sound_button["state"] = "disabled"

            # Record the sample
            if not self.test_mode:
                messagebox.showinfo("Recording", "Recording will start in 3 seconds.\nMake a fish bite sound when ready!")
                time.sleep(3)

            self.audio_detector.record_sample()

            # Show recording details
            sample_info = self.audio_detector.get_sample_info()
            if sample_info:
                info_text = f"Recorded {sample_info['duration']:.1f} seconds\n"
                info_text += f"Max volume: {sample_info['max_volume']:.2f}\n"
                info_text += f"Sample stored in: {sample_info['filepath']}"

                if not self.test_mode:
                    messagebox.showinfo("Recording Complete", info_text)
                    self.show_recording_preview(sample_info['filepath'])

            self.status_label["text"] = "Sound recorded"
            self.record_sound_button["state"] = "normal"
            logger.info("Sound recorded successfully")

        except Exception as e:
            logger.error(f"Error recording sound: {e}")
            self.handle_error(Exception, e, None)

    def show_recording_preview(self, filepath):
        """Show preview dialog for recorded sound"""
        try:
            if not os.path.exists(filepath):
                messagebox.showerror("Error", "Recording file not found!")
                return

            preview = tk.Toplevel(self.root)
            preview.title("Recording Preview")
            preview.geometry("400x200")

            # Show file info
            ttk.Label(preview, text="Recording File:").pack(pady=5)
            ttk.Label(preview, text=os.path.basename(filepath)).pack()

            # Buttons frame
            btn_frame = ttk.Frame(preview)
            btn_frame.pack(pady=20)

            def open_file_location():
                """Open the folder containing the recording"""
                try:
                    if platform.system() == "Windows":
                        os.startfile(os.path.dirname(filepath))
                    elif platform.system() == "Darwin":  # macOS
                        subprocess.Popen(["open", os.path.dirname(filepath)])
                    else:  # Linux
                        subprocess.Popen(["xdg-open", os.path.dirname(filepath)])
                except Exception as e:
                    logger.error(f"Error opening file location: {e}")
                    messagebox.showerror("Error", "Could not open file location")

            def delete_recording():
                """Delete the recording file"""
                try:
                    if messagebox.askyesno("Confirm Delete", "Are you sure you want to delete this recording?"):
                        os.remove(filepath)
                        messagebox.showinfo("Success", "Recording deleted")
                        preview.destroy()
                except Exception as e:
                    logger.error(f"Error deleting recording: {e}")
                    messagebox.showerror("Error", "Could not delete recording")

            ttk.Button(btn_frame, text="Open File Location", command=open_file_location).pack(side="left", padx=5)
            ttk.Button(btn_frame, text="Delete Recording", command=delete_recording).pack(side="left", padx=5)
            ttk.Button(btn_frame, text="Close", command=preview.destroy).pack(side="left", padx=5)

        except Exception as e:
            logger.error(f"Error showing recording preview: {e}")
            messagebox.showerror("Error", "Could not show recording preview")

    def _setup_test_mode(self):
        """Initialize mock GUI for test mode"""
        try:
            # Create mock attributes with command handling
            self.status_label = MockWidget(text="Idle")
            self.start_button = MockWidget(text="Start Bot", command=self.toggle_bot)
            self.record_sound_button = MockWidget(text="Record Fish Bite Sound", command=self.record_sound)
            self.cast_power = MockScale(1.0)
            self.region_label = MockWidget(text="Not Set")
            self.movement_status = MockWidget(text="Movement: Ready")  # Added for test mode
            self.pause_button = MockWidget(text="Pause Movement", command=self.toggle_movement)  # Added for test mode

            # Track GUI state in test mode
            self.is_running = False
            logger.info("Test mode: Mock GUI initialized with command handling")
        except Exception as e:
            logger.error(f"Error setting up test GUI: {e}")

    def simulate_button_click(self, button_name):
        """Simulate clicking a button in test mode"""
        if not self.test_mode:
            return False

        try:
            logger.debug(f"Test mode: Attempting to simulate {button_name} button click")
            if button_name == "start":
                self.start_button.execute()
                logger.info(f"Test mode: Simulated click on {button_name} button")
                return True
            elif button_name == "record":
                self.record_sound_button.execute()
                logger.info(f"Test mode: Simulated click on {button_name} button")
                return True
            return False
        except Exception as e:
            logger.error(f"Error simulating button click: {e}")
            return False

    def mainloop(self):
        if not self.test_mode and hasattr(self, 'root'):
            self.root.mainloop()

    def toggle_bot(self):
        try:
            if self.start_button["text"] == "Start Bot":
                self.start_bot()
            else:
                self.stop_bot()
        except Exception as e:
            logger.error(f"Error toggling bot: {e}")
            self.handle_error(Exception, e, None)

    def start_bot(self):
        """Enhanced start_bot with window checking"""
        try:
            logger.debug("Starting bot")

            # Check for game window first
            if not self.test_mode and not self.screen_analyzer._find_game_window():
                logger.warning("Game window not found during bot start")
                self.status_label["text"] = "Game window not found! Please make sure the game is visible."
                messagebox.showwarning("Warning", "Could not find game window. Please make sure the game is running and visible.")
                return

            self.start_button["text"] = "Stop Bot"
            self.status_label["text"] = "Running"
            self.is_running = True

            # Start detection threads
            self.audio_detector.start_listening(self.on_fish_bite)
            threading.Thread(target=self.screen_monitoring, daemon=True).start()
            logger.info("Bot started successfully")

        except Exception as e:
            logger.error(f"Error starting bot: {e}")
            self.handle_error(Exception, e, None)


    def _init_gui(self):
        """Initialize actual GUI for Windows"""
        try:
            self.root = tk.Tk()
            self.root.title("Fishing Bot")
            self.root.geometry("400x600")
            self.create_widgets()
            logger.info("GUI initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize GUI: {e}")
            self.test_mode = True
            self._setup_test_mode()

    def create_widgets(self):
        if self.test_mode:
            return

        # Status frame
        status_frame = ttk.LabelFrame(self.root, text="Status")
        status_frame.pack(padx=5, pady=5, fill="x")

        self.status_label = ttk.Label(status_frame, text="Idle")
        self.status_label.pack(padx=5, pady=5)

        # Control frame
        control_frame = ttk.LabelFrame(self.root, text="Controls")
        control_frame.pack(padx=5, pady=5, fill="x")

        # Emergency Stop button (added at the top)
        self.emergency_button = ttk.Button(
            control_frame,
            text="EMERGENCY STOP (F6)",
            command=self.emergency_stop,
            style="Emergency.TButton"
        )
        self.emergency_button.pack(padx=5, pady=5, fill="x")

        # Create a custom style for the emergency button
        style = ttk.Style()
        style.configure("Emergency.TButton",
                               background="red",
                               foreground="white",
                               font=("Arial", 10, "bold"))
        style.configure("EmergencyActive.TButton",
                               background="darkred",
                               foreground="white",
                               font=("Arial", 12, "bold"))


        # Start/Stop button
        self.start_button = ttk.Button(
            control_frame,
            text="Start Bot",
            command=self.toggle_bot
        )
        self.start_button.pack(padx=5, pady=5)

        # Record sound button
        self.record_sound_button = ttk.Button(
            control_frame,
            text="Record Fish Bite Sound",
            command=self.record_sound
        )
        self.record_sound_button.pack(padx=5, pady=5)

        # Settings button - Added here with other controls
        self.settings_button = ttk.Button(
            control_frame,
            text="Settings",
            command=self.open_settings
        )
        self.settings_button.pack(padx=5, pady=5)

        # Configuration frame
        config_frame = ttk.LabelFrame(self.root, text="Configuration")
        config_frame.pack(padx=5, pady=5, fill="x")

        ttk.Label(config_frame, text="Cast Power:").pack()
        self.cast_power = ttk.Scale(
            config_frame,
            from_=0.1,
            to=2.0,
            orient="horizontal"
        )
        self.cast_power.set(1.0)
        self.cast_power.pack(padx=5, pady=5, fill="x")

        # Minigame region setup
        ttk.Label(config_frame, text="Set Minigame Region:").pack()
        minigame_frame = ttk.Frame(config_frame)
        minigame_frame.pack(padx=5, pady=5, fill="x")

        self.set_region_button = ttk.Button(
            minigame_frame,
            text="Set Region",
            command=self.set_minigame_region
        )
        self.set_region_button.pack(side="left", padx=5)

        self.region_label = ttk.Label(minigame_frame, text="Not Set")
        self.region_label.pack(side="left", padx=5)

        # Game window region selection
        ttk.Label(config_frame, text="Game Window Region:").pack()
        region_frame = ttk.Frame(config_frame)
        region_frame.pack(padx=5, pady=5, fill="x")

        self.select_window_button = ttk.Button(
            region_frame,
            text="Select Game Window",
            command=self.select_game_window
        )
        self.select_window_button.pack(side="left", padx=5)

        self.window_region_label = ttk.Label(region_frame, text="Not Set")
        self.window_region_label.pack(side="left", padx=5)

        # Add Movement Control frame
        movement_frame = ttk.LabelFrame(self.root, text="Movement Controls")
        movement_frame.pack(padx=5, pady=5, fill="x")

        # Add obstacle management buttons
        ttk.Button(
            movement_frame,
            text="Add Obstacle",
            command=self.add_obstacle
        ).pack(padx=5, pady=2)

        ttk.Button(
            movement_frame,
            text="Clear Obstacles",
            command=self.clear_obstacles
        ).pack(padx=5, pady=2)

        # Movement status
        self.movement_status = ttk.Label(movement_frame, text="Movement: Ready")
        self.movement_status.pack(padx=5, pady=2)

        # Pause/Resume movement button
        self.pause_button = ttk.Button(
            movement_frame,
            text="Pause Movement",
            command=self.toggle_movement
        )
        self.pause_button.pack(padx=5, pady=2)

    def set_minigame_region(self):
        """To be implemented: Allow user to select screen region for minigame"""
        # Placeholder for future implementation
        self.region_label["text"] = "Region Set"

    def on_fish_bite(self):
        try:
            self.game_controller.in_minigame = True
            bite_msg = "Fish bite detected! Starting minigame..."
            self.status_label["text"] = bite_msg
            logger.info(f"Test mode: {bite_msg}")
        except Exception as e:
            logger.error(f"Error handling fish bite: {e}")

    def screen_monitoring(self):
        """Enhanced screen monitoring with window checks"""
        logger.info("Screen monitoring thread started")
        self.is_running = True
        while self.is_running:
            try:
                # Periodic window check
                if not self.check_game_window():
                    continue

                screen = self.screen_analyzer.capture_screen()
                if screen is None:
                    logger.warning("Failed to capture screen")
                    continue

                if self.game_controller.in_minigame:
                    bar_pos = self.screen_analyzer.detect_minigame_bar(screen)
                    if bar_pos is not None:
                        logger.debug(f"Minigame active - bar position {bar_pos:.2f}")
                        self.game_controller.handle_minigame(bar_pos)
                        self.status_label["text"] = f"Playing minigame (bar: {bar_pos:.2f})"
                else:
                    if self.screen_analyzer.detect_fishing_spots(screen):
                        spot = self.screen_analyzer.fishing_spots[0]
                        logger.debug(f"Detected fishing spot at ({spot[0]:.1f}, {spot[1]:.1f})")
                        power = self.cast_power.get()
                        self.game_controller.cast_line(spot[0], spot[1], power)
                        self.status_label["text"] = f"Casting to spot ({spot[0]:.1f}, {spot[1]:.1f})"

            except Exception as e:
                logger.error(f"Error in screen monitoring: {e}")

            time.sleep(0.1)  # Short sleep to prevent high CPU usage

        logger.info("Screen monitoring thread stopped")

    def handle_error(self, exc_type, exc_value, exc_traceback):
        error_message = f"An error occurred: {str(exc_value)}"
        logger.error(error_message, exc_info=(exc_type, exc_value, exc_traceback))
        if not self.test_mode:
            messagebox.showerror("Error", error_message)

    def open_settings(self):
        """Open the settings panel"""
        try:
            if self.test_mode:
                logger.info("Test mode: Opening mock settings panel")
                MockSettingsPanel(None, self.config)
            else:
                SettingsPanel(self.root, self.config)
        except Exception as e:
            logger.error(f"Error opening settings: {e}")

    def select_game_window(self):
        """Open the region selector to select game window area"""
        try:
            if self.test_mode:
                logger.info("Test mode: Using default game window region")
                self.window_region_label["text"] = "Test Mode: 800x600"
                return

            def save_region(region):
                """Callback to save the selected region"""
                try:
                    x1, y1, x2, y2 = region
                    width = x2 - x1
                    height = y2 - y1

                    # Update UI and config
                    self.window_region_label["text"] = f"{width}x{height}"
                    self.config.update_category('window', {
                        'x': x1,
                        'y': y1,
                        'width': width,
                        'height': height,
                        'use_full_screen': False
                    })

                    # Update screen analyzer
                    self.screen_analyzer.set_window_region(region)
                    logger.info(f"Game window region set: {width}x{height}")

                    messagebox.showinfo(
                        "Success",
                        f"Game window selection saved ({width}x{height})"
                    )

                except Exception as e:
                    logger.error(f"Error saving region: {e}")
                    messagebox.showerror("Error", "Could not save window selection")

            # Create and show the region selector
            selector = ScreenRegionSelector(callback=save_region)
            selector.get_region()

        except Exception as e:
            logger.error(f"Error in window selection: {e}")
            messagebox.showerror("Error", "Could not start window selection")

    def simulate_emergency_stop(self):
        """Test mode: Simulate emergency stop activation"""
        if not self.test_mode:
            return False

        try:
            logger.info("Test mode: Simulating emergency stop")
            self.emergency_stop()
            return True
        except Exception as e:
            logger.error(f"Error simulating emergency stop: {e}")
            return False

    def simulate_recording(self):
        """Test mode: Simulate recording process"""
        if not self.test_mode:
            return False

        try:
            logger.info("Test mode: Starting recording simulation")
            self.record_sound()
            return True
        except Exception as e:
            logger.error(f"Error simulating recording: {e}")
            return False

    def add_obstacle(self):
        """Add current mouse position as obstacle"""
        try:
            if self.test_mode:
                logger.debug("Test mode: Simulated adding obstacle")
                return

            if pyautogui is None:
                logger.warning("pyautogui not available, cannot add obstacle")
                return

            x, y = pyautogui.position()
            self.game_controller.add_obstacle(x, y)
            messagebox.showinfo("Success", f"Added obstacle at position ({x}, {y})")
        except Exception as e:
            logger.error(f"Error adding obstacle: {e}")
            self.handle_error(Exception, e, None)

    def clear_obstacles(self):
        """Clear all pathfinding obstacles"""
        try:
            self.game_controller.clear_obstacles()
            if not self.test_mode:
                messagebox.showinfo("Success", "Cleared all obstacles")
        except Exception as e:
            logger.error(f"Error clearing obstacles: {e}")
            self.handle_error(Exception, e, None)

    def toggle_movement(self):
        """Toggle movement pause state"""
        try:
            if self.game_controller.movement_paused:
                self.game_controller.resume_movement()
                self.pause_button["text"] = "Pause Movement"
                self.movement_status["text"] = "Movement: Active"
            else:
                self.game_controller.pause_movement()
                self.pause_button["text"] = "Resume Movement"
                self.movement_status["text"] = "Movement: Paused"
        except Exception as e:
            logger.error(f"Error toggling movement: {e}")
            self.handle_error(Exception, e, None)


class MockWidget:
    """Mock implementation for testing"""
    def __init__(self, command=None, text=""):
        self.command = command
        self.text = text
        self.enabled = True
        self.style = None

    def execute(self):
        """Execute the mock widget's command"""
        if self.enabled and self.command:
            try:
                self.command()
                logger.debug(f"Mock widget '{self.text}' command executed")
                return True
            except Exception as e:
                logger.error(f"Error executing mock widget command: {e}")
        return False

    def __getitem__(self, key):
        if key == "text":
            return self.text
        elif key == "state":
            return "normal" if self.enabled else "disabled"
        elif key == "style":
            return self.style
        raise KeyError(f"Invalid key: {key}")

    def __setitem__(self, key, value):
        if key == "text":
            self.text = value
        elif key == "state":
            self.enabled = value == "normal"
        elif key == "style":
            self.style = value

    def configure(self, style):
        """Configure widget style"""
        self.style = style


class MockScale:
    """Mock implementation for testing"""
    def __init__(self, default_value):
        self.value = default_value

    def get(self):
        """Get current value"""
        return self.value

    def set(self, value):
        """Set new value"""
        self.value = value