import sys
import threading
import logging
import platform
import os
import time
from platform_handler import PlatformHandler

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('fishing_bot.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

def init_platform_specifics():
    """Initialize platform-specific settings with enhanced Windows support"""
    try:
        # Initialize platform handler first
        platform_handler = PlatformHandler()

        # Log platform information
        logger.info(f"Initializing on platform: {platform.system()}")
        logger.info(f"Python version: {platform.python_version()}")
        logger.info(f"Platform release: {platform.release()}")

        # Initialize display with enhanced error handling
        if not platform_handler.init_display():
            logger.error("Failed to initialize display - Please run as administrator")
            print("\nError: Failed to initialize display.")
            print("Please try the following:")
            print("1. Run the bot as administrator (right-click -> Run as Administrator)")
            print("2. Ensure the game window is not minimized")
            print("3. If issues persist, you can manually select the game region\n")
            return False

        # Get screen dimensions
        width, height = platform_handler.get_screen_size()
        logger.info(f"Screen dimensions: {width}x{height}")

        logger.info("Platform specific initialization complete")
        return True
    except Exception as e:
        logger.error(f"Error in platform initialization: {e}", exc_info=True)
        return False

def main():
    try:
        # Initialize platform-specific settings
        if not init_platform_specifics():
            logger.error("Critical: Failed to initialize platform-specific settings")
            sys.exit(1)

        # Initialize core components
        logger.info("Initializing core components...")

        try:
            from audio_detector import AudioDetector
            audio_detector = AudioDetector()
            logger.info("Audio detector initialized")
        except Exception as e:
            logger.error(f"Failed to initialize audio detector: {e}")
            sys.exit(1)

        try:
            from screen_analyzer import ScreenAnalyzer
            screen_analyzer = ScreenAnalyzer()
            logger.info("Screen analyzer initialized")
        except Exception as e:
            logger.error(f"Failed to initialize screen analyzer: {e}")
            sys.exit(1)

        try:
            from game_controller import GameController
            game_controller = GameController()
            logger.info("Game controller initialized")
        except Exception as e:
            logger.error(f"Failed to initialize game controller: {e}")
            sys.exit(1)

        # Create GUI with error handling
        try:
            logger.info("Starting GUI...")
            from gui import FishingBotGUI
            gui = FishingBotGUI(audio_detector, screen_analyzer, game_controller)

            # Start GUI main loop
            logger.info("Starting GUI main loop")
            gui.mainloop()

        except ImportError as e:
            logger.error(f"Failed to initialize GUI: {e}")
            sys.exit(1)

    except Exception as e:
        logger.error(f"Critical error in main: {e}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main()