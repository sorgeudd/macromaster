# Fishing Bot - Easy Installation Guide

## Requirements

- Windows operating system
- Python 3.11 or higher
- Internet connection (for installation)

## Step 1: Install Python
1. Go to [python.org](https://www.python.org/downloads/)
2. Click the big yellow "Download Python 3.11" button
3. Run the installer you downloaded
4. **IMPORTANT**: Check the box that says "Add Python to PATH" at the bottom of the installer
5. Click "Install Now"

## Step 2: Install the Bot
1. Extract the `fishing-bot.zip` file you downloaded
2. Open the folder you extracted
3. Double-click `start_bot.bat`
   - The first time you run it, it will install everything needed
   - You might see a black window with text - this is normal!
   - Wait until it's done (usually takes 1-2 minutes)

## Step 3: Use the Bot

### Basic Controls
- Click "Record Fish Bite Sound" to teach the bot what a bite sounds like
- Use the "Settings" button to adjust how the bot works
- Click "Start Bot" to begin fishing!

### Setting Up the Game Window
1. Click "Select Game Window" in the bot interface
2. A semi-transparent overlay will appear
3. Click and drag to select your game window area
4. Release to confirm selection
5. Press Escape to cancel if needed

### AI-Enhanced Learning Features
The bot now includes an advanced learning system that improves its performance over time:

1. **Basic Learning Mode**:
   - The bot automatically learns from your fishing patterns
   - Adjusts timing and strategy based on success rate
   - No additional setup required

2. **Advanced AI Mode (Optional)**:
   - Get better predictions with AI assistance
   - To enable:
     1. Get an API token from [Hugging Face](https://huggingface.co/settings/tokens)
     2. Create a file named `.env` in the bot folder
     3. Add this line: `HUGGINGFACE_API_TOKEN=your_token_here`
     4. Restart the bot

3. **Testing the Learning System**:
   - Run `python test_learning.py` to see how the learning works
   - The test will show:
     - Basic pattern learning
     - AI-enhanced predictions (if token is set)
     - Success rate improvements

### Movement Controls
The bot includes an advanced pathfinding system for character movement:

1. **Adding Obstacles**:
   - Click "Add Obstacle" and click anywhere on the game screen to mark areas the bot should avoid
   - Use "Clear Obstacles" to remove all marked obstacles

2. **Movement Controls**:
   - The bot will automatically navigate between fishing spots
   - Use "Pause Movement" to temporarily stop movement
   - Click "Resume Movement" to continue

3. **Movement Settings**:
   - Adjust "Path Smoothing" to make movement more natural
   - Change "Random Variance" to add slight randomization to movement

### Emergency Controls
- Press F6 or click "EMERGENCY STOP" to immediately stop all bot actions
- The bot will automatically avoid screen edges and obstacles

## Common Problems and Solutions

1. If you see "error: subprocess-exited-with-error":
   - Open Command Prompt as Administrator
   - Type: `python -m pip install --upgrade pip`
   - Try running start_bot.bat again

2. If you see "No module named 'something'":
   - Open Command Prompt
   - Type `cd ` (with a space after cd)
   - Drag the fishing-bot folder onto the Command Prompt window
   - Press Enter
   - Type: `python -m pip install numpy opencv-python pillow pyaudio pyautogui`
   - Try running start_bot.bat again

3. If PyAudio won't install:
   - Download the correct PyAudio wheel for your Python version from:
   - https://www.lfd.uci.edu/~gohlke/pythonlibs/#pyaudio
   - Install it using: `pip install PyAudio‑0.2.11‑cp311‑cp311‑win_amd64.whl`

## Note
- The bot requires Windows
- Your game window must be visible (not minimized)
- Some antivirus software might need you to approve PyAutoGUI
- Make sure to set up obstacles around areas you want the bot to avoid
- Movement settings can be adjusted in the Settings panel under the "Movement" tab
- The learning system works best with more data - let it run for a while to improve accuracy