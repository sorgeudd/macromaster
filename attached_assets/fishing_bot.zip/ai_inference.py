import logging
import requests
import json
from typing import Dict, Any, Optional
import os
import numpy as np

logger = logging.getLogger(__name__)

class AIInference:
    def __init__(self):
        self.api_url = "https://api-inference.huggingface.co/models/facebook/bart-large"
        self.api_token = os.environ.get("HUGGINGFACE_API_TOKEN", "")
        self.headers = {"Authorization": f"Bearer {self.api_token}"}
        self.cache = {}
        if not self.api_token:
            logger.warning("No Hugging Face API token found - using fallback predictions")

    def _format_gameplay_data(self, gameplay_data: Dict[str, Any]) -> str:
        """Format gameplay data into text for the model with improved list handling"""
        try:
            # Convert gameplay data into a structured prompt
            prompt = "Analyze fishing pattern:\n"

            if 'timing' in gameplay_data:
                # Handle cast_to_bite times (get average if list exists)
                cast_times = gameplay_data['timing'].get('cast_to_bite', [])
                if cast_times:
                    if isinstance(cast_times, list):
                        avg_cast_time = np.mean(cast_times[-10:])  # Use last 10 attempts
                        prompt += f"Cast to bite time: {avg_cast_time:.2f}s\n"
                    else:
                        prompt += f"Cast to bite time: {float(cast_times):.2f}s\n"

                # Handle bite_to_hook times
                hook_times = gameplay_data['timing'].get('bite_to_hook', [])
                if hook_times:
                    if isinstance(hook_times, list):
                        avg_hook_time = np.mean(hook_times[-10:])  # Use last 10 attempts
                        prompt += f"Bite to hook time: {avg_hook_time:.2f}s\n"
                    else:
                        prompt += f"Bite to hook time: {float(hook_times):.2f}s\n"

                # Success rate is already a float
                success_rate = gameplay_data['timing'].get('success_rate', 0)
                prompt += f"Success rate: {success_rate:.2%}\n"

            if 'minigame' in gameplay_data:
                click_timings = gameplay_data['minigame'].get('click_timings', [])
                if click_timings:
                    if isinstance(click_timings, list):
                        avg_timing = np.mean(click_timings[-10:])  # Use last 10 clicks
                        prompt += f"Average click timing: {avg_timing:.2f}\n"
                    else:
                        prompt += f"Click timing: {float(click_timings):.2f}\n"

            logger.info(f"Formatted gameplay data:\n{prompt}")
            return prompt
        except Exception as e:
            logger.error(f"Error formatting gameplay data: {e}")
            return "Default fishing pattern analysis request"

    def analyze_gameplay_pattern(self, gameplay_data: Dict[str, Any]) -> Dict[str, float]:
        """
        Analyze gameplay patterns using Hugging Face model
        Returns confidence scores for different actions
        """
        try:
            # Format the gameplay data for inference
            input_text = self._format_gameplay_data(gameplay_data)

            logger.info(f"Analyzing gameplay pattern:\n{input_text}")

            # Check cache first
            if input_text in self.cache:
                logger.info("Using cached analysis result")
                return self.cache[input_text]

            if not self.api_token:
                logger.info("No API token - using fallback predictions")
                return self._get_fallback_prediction()

            # Prepare the payload
            payload = {
                "inputs": input_text,
                "parameters": {
                    "max_length": 100,
                    "top_k": 3,
                    "temperature": 0.7
                }
            }

            # Make API request
            response = requests.post(self.api_url, headers=self.headers, json=payload)

            if response.status_code == 200:
                result = response.json()
                # Process and format the results
                processed_result = self._process_inference_result(result)
                logger.info(f"AI analysis complete: {processed_result}")
                # Cache the result
                self.cache[input_text] = processed_result
                return processed_result
            else:
                logger.error(f"API request failed with status code: {response.status_code}")
                return self._get_fallback_prediction()

        except Exception as e:
            logger.error(f"Error in gameplay pattern analysis: {e}")
            return self._get_fallback_prediction()

    def _process_inference_result(self, result: Any) -> Dict[str, float]:
        """Process and structure the model's output"""
        try:
            predictions = {
                'optimal_timing': 0.5,  # Default timing
                'movement_confidence': 0.5,  # Default movement confidence
                'pattern_reliability': 0.5  # Default pattern reliability
            }

            if isinstance(result, list) and len(result) > 0:
                text_output = result[0].get('generated_text', '')
                logger.info(f"Processing AI output: {text_output}")

                if 'timing' in text_output.lower():
                    timing_value = self._extract_numeric_value(text_output)
                    if timing_value is not None:
                        predictions['optimal_timing'] = timing_value

                if 'confidence' in text_output.lower():
                    conf_value = self._extract_numeric_value(text_output)
                    if conf_value is not None:
                        predictions['movement_confidence'] = conf_value

                logger.info(f"Processed predictions: {predictions}")
            return predictions

        except Exception as e:
            logger.error(f"Error processing inference result: {e}")
            return self._get_fallback_prediction()

    def _extract_numeric_value(self, text: str) -> Optional[float]:
        """Extract numeric value from text"""
        try:
            import re
            numbers = re.findall(r"[-+]?\d*\.\d+|\d+", text)
            if numbers:
                value = float(numbers[0])
                # Normalize to [0,1] if necessary
                if value > 1:
                    value = value / 100.0
                return max(0.0, min(1.0, value))
            return None
        except Exception:
            return None

    def _get_fallback_prediction(self) -> Dict[str, float]:
        """Return fallback predictions when inference fails"""
        fallback = {
            'optimal_timing': 0.5,
            'movement_confidence': 0.5,
            'pattern_reliability': 0.5
        }
        logger.info(f"Using fallback predictions: {fallback}")
        return fallback

    def update_api_token(self, token: str):
        """Update the API token"""
        self.api_token = token
        self.headers = {"Authorization": f"Bearer {token}"}
        logger.info("API token updated successfully")