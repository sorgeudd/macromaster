import platform
import logging
import os
import sys
import types
import time
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

class PlatformHandler:
    def __init__(self):
        self.is_windows = platform.system().lower() == 'windows'
        # Set test_mode True by default for non-Windows systems
        self.test_mode = not self.is_windows
        self.active_window = None
        self.window_region = None

        logger.info(f"Platform system detected: {platform.system()}")
        logger.info(f"Is Windows: {self.is_windows}")
        logger.info(f"Test mode: {self.test_mode}")

        if self.test_mode:
            logger.info("Initializing in test/development mode")
            self._setup_test_environment()
        else:
            try:
                import pyautogui
                pyautogui.PAUSE = 0.1
                pyautogui.FAILSAFE = True
                self._show_windows_instructions()
            except Exception as e:
                logger.error(f"Failed to initialize platform handler: {e}")
                self.test_mode = True
                self._setup_test_environment()

    def _show_windows_instructions(self):
        """Show important setup instructions for Windows users"""
        instructions = """
Important Windows Setup Instructions:
1. Run the bot as administrator (right-click -> Run as Administrator)
2. Ensure the game window is not minimized
3. If window detection fails, you can manually select the game region
4. Disable Windows Game Mode and overlays that might interfere
5. Make sure you're running the game in windowed mode, not fullscreen
"""
        logger.info(instructions)
        print(instructions)

    def _setup_test_environment(self):
        """Set up test environment with mocked functionality"""
        try:
            os.environ['DISPLAY'] = ':0'  # Set display for headless environments
            os.environ['PYTHONUNBUFFERED'] = '1'

            mock_module = types.ModuleType('pyautogui')

            def mock_function(*args, **kwargs):
                caller_name = sys._getframe().f_back.f_code.co_name
                logger.debug(f"Test mode: {caller_name} called with args={args}, kwargs={kwargs}")
                return None

            mock_window = types.SimpleNamespace(
                title='Test Game Window',
                left=0,
                top=0,
                width=1280,
                height=720,
                activate=lambda: logger.debug("Test mode: Window activated")
            )

            mock_attrs = {
                'FAILSAFE': True,
                'PAUSE': 0.1,
                'click': mock_function,
                'moveTo': mock_function,
                'mouseDown': mock_function,
                'mouseUp': mock_function,
                'press': mock_function,
                'size': lambda: (1920, 1080),
                'position': lambda: (0, 0),
                'getWindowsWithTitle': lambda title: [mock_window] if title == '' else []
            }

            for attr, value in mock_attrs.items():
                setattr(mock_module, attr, value)

            sys.modules['pyautogui'] = mock_module
            logger.info("Test environment configured successfully")

            # Set default test window region
            self.window_region = (0, 0, 1280, 720)

        except Exception as e:
            logger.error(f"Error setting up test environment: {e}")

    def find_game_window(self, window_title_keywords=None) -> bool:
        """Find game window using PyAutoGUI with enhanced detection"""
        if self.test_mode:
            logger.info("Test mode: Using default game window region")
            self.window_region = (0, 0, 1280, 720)
            return True

        try:
            if window_title_keywords is None:
                window_title_keywords = ['game', 'client', 'albion', 'fishing']

            import pyautogui
            windows = pyautogui.getWindowsWithTitle('')
            viable_windows = []

            for window in windows:
                try:
                    title = window.title.lower()
                    if any(keyword.lower() in title for keyword in window_title_keywords):
                        logger.info(f"Found potential game window: '{window.title}'")
                        viable_windows.append(window)
                except Exception as e:
                    logger.debug(f"Error checking window: {e}")
                    continue

            if viable_windows:
                window = viable_windows[0]
                try:
                    window.activate()
                    time.sleep(0.5)
                    self.window_region = (window.left, window.top,
                                        window.left + window.width,
                                        window.top + window.height)
                    logger.info(f"Successfully activated window: {window.title}")
                    return True
                except Exception as e:
                    logger.error(f"Failed to activate window: {e}")
                    return False

            logger.warning("No matching game windows found")
            return False

        except Exception as e:
            logger.error(f"Error in game window detection: {e}")
            return False

    def ensure_game_window_focused(self) -> bool:
        """Ensure game window is focused for interaction"""
        if self.test_mode:
            logger.debug("Test mode: Window focus simulated")
            return True

        try:
            if self.window_region:
                import pyautogui
                center_x = (self.window_region[0] + self.window_region[2]) // 2
                center_y = (self.window_region[1] + self.window_region[3]) // 2

                original_x, original_y = pyautogui.position()
                pyautogui.moveTo(center_x, center_y)
                pyautogui.click()
                pyautogui.moveTo(original_x, original_y)
                return True
            return False
        except Exception as e:
            logger.error(f"Error focusing window: {e}")
            return False

    def get_window_region(self):
        """Get the current window region"""
        return self.window_region

    def init_display(self):
        """Initialize display settings"""
        if self.test_mode:
            logger.info("Test mode: Display initialization skipped")
            return True

        try:
            import pyautogui
            pyautogui.FAILSAFE = True
            pyautogui.PAUSE = 0.1
            return True
        except Exception as e:
            logger.error(f"Failed to initialize display: {e}")
            return False

    def get_screen_size(self) -> Tuple[int, int]:
        """Get screen dimensions"""
        if self.test_mode:
            return (1920, 1080)
        try:
            import pyautogui
            return pyautogui.size()
        except Exception as e:
            logger.error(f"Error getting screen size: {e}")
            return (800, 600)

    def set_window_region(self, region):
        """Manually set the game window region"""
        try:
            if not all(isinstance(v, (int, float)) for v in region):
                raise ValueError("Invalid region coordinates")
            self.window_region = tuple(int(v) for v in region)
            logger.info(f"Manual window region set to: {self.window_region}")
            return True
        except Exception as e:
            logger.error(f"Error setting window region: {e}")
            return False