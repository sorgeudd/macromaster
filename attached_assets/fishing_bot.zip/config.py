import json
import os
import logging

logger = logging.getLogger(__name__)

class Config:
    DEFAULT_CONFIG = {
        'audio': {
            'threshold': 0.08,  # Reduced threshold for more sensitive detection
            'sample_rate': 44100,
            'chunk_size': 1024,
            'recording_duration': 1.5  # Reduced for quicker response
        },
        'fishing_spot': {
            'min_radius': 20,
            'max_radius': 100,
            'detection_interval': 0.5,
            'movement_speed': 1.2  # Increased for better responsiveness
        },
        'minigame': {
            'bar_left_boundary': 0.2,
            'bar_right_boundary': 0.8,
            'reaction_speed': 1.0,
            'click_interval': 0.1
        },
        'movement': {
            'base_delay': 0.3,        # Reduced from 0.5 for faster response
            'random_variance': 0.08,   # Reduced from 0.1 for more precise movement
            'path_smoothing': 0.85,    # Increased from 0.7 for smoother movement
            'mounted_speed_multiplier': 1.5
        },
        'combat': {
            'skill_delay': 0.08,      # Reduced from 0.1 for faster skill activation
            'auto_heal_threshold': 0.65,  # Increased from 0.5 for earlier healing
            'skill_cooldowns': {
                '2': 7.5,  # Slightly reduced from 8.0
                '3': 11.0, # Slightly reduced from 12.0
                '4': 14.0  # Slightly reduced from 15.0
            },
            'combat_range': 120  # Increased from 100 for better engagement range
        },
        'gathering': {
            'interaction_range': 50,
            'gather_delay': 0.5,
            'detection_radius': 30
        },
        'window': {
            'x': 0,
            'y': 0,
            'width': 800,
            'height': 600,
            'use_full_screen': True
        }
    }

    def __init__(self):
        self.config_path = 'bot_settings.json'
        self.settings = self.load_settings()

    def load_settings(self):
        """Load settings from file or create with defaults"""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r') as f:
                    loaded_settings = json.load(f)
                    # Merge with defaults to ensure all keys exist
                    return self._merge_with_defaults(loaded_settings)
            else:
                self.save_settings(self.DEFAULT_CONFIG)
                return self.DEFAULT_CONFIG.copy()
        except Exception as e:
            logger.error(f"Error loading settings: {e}")
            return self.DEFAULT_CONFIG.copy()

    def save_settings(self, settings):
        """Save current settings to file"""
        try:
            with open(self.config_path, 'w') as f:
                json.dump(settings, f, indent=4)
            logger.info("Settings saved successfully")
            return True
        except Exception as e:
            logger.error(f"Error saving settings: {e}")
            return False

    def _merge_with_defaults(self, loaded_settings):
        """Ensure all default keys exist in loaded settings"""
        merged = self.DEFAULT_CONFIG.copy()
        for category in loaded_settings:
            if category in merged:
                merged[category].update(loaded_settings[category])
        return merged

    def update_category(self, category, values):
        """Update a specific category of settings"""
        if category in self.settings:
            self.settings[category].update(values)
            self.save_settings(self.settings)
            return True
        return False

    def get_category(self, category):
        """Get settings for a specific category"""
        return self.settings.get(category, {})

    def reset_to_defaults(self):
        """Reset all settings to default values"""
        self.settings = self.DEFAULT_CONFIG.copy()
        self.save_settings(self.settings)
        return True