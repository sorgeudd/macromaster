import numpy as np
import time

def calculate_distance(point1, point2):
    """Calculate Euclidean distance between two points"""
    return np.sqrt((point2[0] - point1[0])**2 + (point2[1] - point1[1])**2)

def smooth_movement(start_x, start_y, end_x, end_y, steps=20):
    """Generate smooth movement coordinates"""
    x_steps = np.linspace(start_x, end_x, steps)
    y_steps = np.linspace(start_y, end_y, steps)
    return list(zip(x_steps, y_steps))

def add_random_delay(base_delay, variance=0.1):
    """Add random delay to avoid detection"""
    random_offset = np.random.uniform(-variance, variance)
    time.sleep(base_delay + random_offset)
