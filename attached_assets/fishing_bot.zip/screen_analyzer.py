import cv2
import numpy as np
from PIL import ImageGrab
import logging
import sys
import platform
from typing import Optional, Tuple, List
import time
import random
import pyautogui

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ScreenAnalyzer:
    def __init__(self):
        self.fishing_spots: List[np.ndarray] = []
        self.minigame_region: Optional[Tuple[int, int, int, int]] = None
        self.template_fish_ring = None
        self.game_window = None
        self.window_region = None
        self.is_windows = platform.system() == 'Windows'
        self.test_mode = False
        self.platform_handler = None

        # Initialize platform handler
        try:
            from platform_handler import PlatformHandler
            self.platform_handler = PlatformHandler()

            if not self.test_mode:
                self._find_game_window()
                self.capture_screen()
                logger.info("Screen analyzer initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize screen analyzer: {e}")
            self.test_mode = True
            self._setup_test_mode()

    def _find_game_window(self):
        """Find the game window with enhanced detection"""
        try:
            if not self.is_windows:
                logger.warning("Window detection only supported on Windows")
                return False

            logger.info("Beginning game window detection...")

            # Try to find game window using platform handler
            if self.platform_handler.find_game_window():
                self.window_region = self.platform_handler.get_window_region()
                logger.info(f"Game window detected and region set: {self.window_region}")
                return True

            # If no game window found, check for manual region
            if self.window_region:
                logger.info(f"Using manual window region: {self.window_region}")
                return True

            logger.warning("No suitable game window found - Please run as administrator or set region manually")
            return False

        except Exception as e:
            logger.error(f"Error in game window detection: {e}")
            return False

    def set_window_region(self, region):
        """Set window region manually"""
        try:
            if self.platform_handler.set_window_region(region):
                self.window_region = region
                logger.info(f"Window region set successfully: {region}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error setting window region: {e}")
            return False

    def capture_screen(self, region=None):
        """Capture screen with improved window handling"""
        try:
            if self.test_mode:
                width = 800 if region is None else region[2] - region[0]
                height = 600 if region is None else region[3] - region[1]
                logger.debug(f"Test mode: Simulating screen capture ({width}x{height})")
                return np.zeros((height, width, 3), dtype=np.uint8)

            # Ensure game window is focused
            if self.is_windows:
                self.platform_handler.ensure_game_window_focused()

            # Use specified region or stored window region
            capture_region = region or self.window_region

            if capture_region is None:
                logger.warning("No specific region set, capturing full screen")
                screenshot = ImageGrab.grab()
            else:
                logger.debug(f"Capturing specific region: {capture_region}")
                screenshot = ImageGrab.grab(bbox=capture_region)

            # Convert to numpy array and BGR format for OpenCV
            screen = np.array(screenshot)
            return cv2.cvtColor(screen, cv2.COLOR_RGB2BGR)

        except Exception as e:
            logger.error(f"Error capturing screen: {e}")
            return None

    # Movement simulation parameters
    current_velocity = np.zeros(2)
    max_velocity = 5.0
    acceleration = 0.5
    last_position = None

    # Test mode minigame parameters
    test_minigame_position = 0.5
    test_direction = 1

    def _setup_test_mode(self):
        """
        Configure test mode simulation parameters.
        """
        # Initialize with multiple test fishing spots (x, y coordinates only)
        self.test_fishing_spots = np.array([
            [400, 300],  # Spot 1: Center-left
            [600, 400],  # Spot 2: Center-right
            [300, 500]   # Spot 3: Bottom-left
        ])
        self.current_spot_index = 0
        # Initialize last position to first spot
        self.last_position = self.test_fishing_spots[0].copy()
        logger.info("Test mode: Initialized with multiple fishing spots")

    def detect_fishing_spots(self, screen: Optional[np.ndarray]) -> bool:
        """
        Detect fishing spot rings in the water with smooth movement simulation.
        """
        if screen is None:
            return False

        try:
            if self.test_mode:
                # Get current target spot
                target_spot = self.test_fishing_spots[self.current_spot_index]

                # Initialize last_position if None
                if self.last_position is None:
                    self.last_position = target_spot.copy()
                    logger.info(f"Test mode: Initialized position at ({self.last_position[0]:.1f}, {self.last_position[1]:.1f})")
                    return True

                # Calculate direction to target
                direction = target_spot - self.last_position
                distance = np.linalg.norm(direction)

                # Enhanced status logging for fishing spots
                logger.info(
                    f"Test mode: Current Status\n"
                    f"  - Active Spot: {self.current_spot_index + 1}\n"
                    f"  - Position: ({self.last_position[0]:.1f}, {self.last_position[1]:.1f})\n"
                    f"  - Target: ({target_spot[0]:.1f}, {target_spot[1]:.1f})\n"
                    f"  - Distance: {distance:.1f}\n"
                    f"  - Velocity: ({self.current_velocity[0]:.2f}, {self.current_velocity[1]:.2f})"
                )

                # If we're close enough to current target, switch to next spot
                if distance < 10.0:
                    old_index = self.current_spot_index
                    self.current_spot_index = (self.current_spot_index + 1) % len(self.test_fishing_spots)
                    target_spot = self.test_fishing_spots[self.current_spot_index]
                    logger.info(
                        f"Test mode: Transitioning to new spot\n"
                        f"  - Previous: Spot {old_index + 1}\n"
                        f"  - New: Spot {self.current_spot_index + 1}\n"
                        f"  - New Target: ({target_spot[0]:.1f}, {target_spot[1]:.1f})"
                    )
                    direction = target_spot - self.last_position
                    distance = np.linalg.norm(direction)

                # Calculate desired velocity (normalized direction * base speed)
                if distance > 0:
                    # Further reduced max speed to 70% of limit for better safety margin
                    desired_velocity = direction / distance * min(distance, self.max_velocity * 0.7)
                    logger.debug(
                        f"Test mode: Desired velocity: ({desired_velocity[0]:.2f}, {desired_velocity[1]:.2f})"
                    )
                else:
                    desired_velocity = np.zeros(2)

                # Smoothly adjust current velocity with reduced acceleration
                velocity_diff = desired_velocity - self.current_velocity
                acceleration = velocity_diff * self.acceleration * 0.1  # Further reduced from 0.15
                self.current_velocity += acceleration

                logger.debug(
                    f"Test mode: Acceleration: ({acceleration[0]:.3f}, {acceleration[1]:.3f})"
                )

                # Add minimal random movement with tighter bounds
                random_offset = np.random.normal(0, 0.03, 2)  # Reduced from 0.05
                total_movement = self.current_velocity + random_offset * 0.03

                # Strictly enforce velocity limit with absolute cap
                speed = np.linalg.norm(total_movement)
                original_speed = speed

                if speed > 0:  # Avoid division by zero
                    max_allowed = self.max_velocity * 0.98  # Increased safety margin to 98%
                    if speed > max_allowed:
                        total_movement *= max_allowed / speed
                        # Add absolute cap to handle floating point imprecision
                        if np.linalg.norm(total_movement) > self.max_velocity:
                            total_movement *= 0.99  # Additional 1% reduction if still over
                        logger.info(
                            f"Test mode: Velocity limit enforced - Original: {original_speed:.2f}, "
                            f"Adjusted: {np.linalg.norm(total_movement):.2f}"
                        )

                # Update position
                new_position = self.last_position + total_movement

                # Enforce screen boundaries
                new_position = np.clip(new_position, [0, 0], [800, 600])

                # Store new position and create fishing spot
                self.last_position = new_position
                spot_with_radius = np.append(new_position, [30])  # Add constant radius
                self.fishing_spots = np.array([spot_with_radius])

                # Detailed movement logging
                logger.debug(
                    f"Test mode: Moving to spot {self.current_spot_index + 1} - "
                    f"Position: ({new_position[0]:.1f}, {new_position[1]:.1f}), "
                    f"Speed: {speed:.2f}, Distance to target: {distance:.1f}, "
                    f"Movement: ({total_movement[0]:.3f}, {total_movement[1]:.3f})"
                )
                return True

            # Real mode implementation - enhanced for the game's specific pattern
            gray = cv2.cvtColor(screen, cv2.COLOR_BGR2GRAY)
            blurred = cv2.GaussianBlur(gray, (9, 9), 2)

            # Convert to HSV to better detect blue circles
            hsv = cv2.cvtColor(screen, cv2.COLOR_BGR2HSV)
            # Blue color range in HSV
            lower_blue = np.array([100, 50, 50])
            upper_blue = np.array([130, 255, 255])
            blue_mask = cv2.inRange(hsv, lower_blue, upper_blue)

            # Combine with edge detection
            edges = cv2.Canny(blurred, 50, 150)
            combined_mask = cv2.bitwise_and(blue_mask, edges)

            # Enhanced parameters for blue circular pattern detection
            circles = cv2.HoughCircles(
                combined_mask,
                cv2.HOUGH_GRADIENT,
                dp=1,
                minDist=50,
                param1=50,
                param2=25,  # Lowered to detect slightly fainter circles
                minRadius=15,
                maxRadius=40  # Adjusted based on screenshot
            )

            if circles is not None:
                self.fishing_spots = circles[0]
                logger.info(f"Detected {len(circles[0])} fishing spots")
                return True
            return False

        except Exception as e:
            logger.error(f"Error detecting fishing spots: {e}")
            return False

    def detect_minigame_bar(self, screen: Optional[np.ndarray]) -> Optional[float]:
        """
        Detect the position of the bar in the fishing minigame.
        """
        if screen is None or (self.minigame_region is None and not self.test_mode):
            return None

        try:
            if self.test_mode:
                # Calculate dynamic speed based on position
                position = self.test_minigame_position
                base_speed = 0.05

                # Add acceleration near edges
                edge_distance = min(position, 1 - position)
                speed_multiplier = 1 + (0.5 * (1 - edge_distance))  # Speed up near edges

                # Add some randomness to movement
                random_factor = random.uniform(0.8, 1.2)
                final_speed = base_speed * speed_multiplier * random_factor

                # Update position
                self.test_minigame_position += final_speed * self.test_direction

                # Enhanced minigame status logging
                logger.info(
                    f"Test mode: Minigame Status\n"
                    f"  - Bar Position: {self.test_minigame_position:.2f}\n"
                    f"  - Movement: {'Right' if self.test_direction > 0 else 'Left'}\n"
                    f"  - Speed: {final_speed:.3f}\n"
                    f"  - Edge Distance: {edge_distance:.2f}"
                )

                # Bounce at boundaries with slight randomization
                if self.test_minigame_position > 0.95 or self.test_minigame_position < 0.05:
                    old_direction = "Right" if self.test_direction > 0 else "Left"
                    self.test_direction *= -1
                    new_direction = "Right" if self.test_direction > 0 else "Left"
                    # Add slight random adjustment to bounce position
                    self.test_minigame_position += random.uniform(-0.02, 0.02)
                    logger.info(
                        f"Test mode: Bar Direction Change\n"
                        f"  - Previous: {old_direction}\n"
                        f"  - New: {new_direction}\n"
                        f"  - Position: {self.test_minigame_position:.2f}"
                    )

                # Ensure position stays within bounds
                self.test_minigame_position = max(0.0, min(1.0, self.test_minigame_position))
                return self.test_minigame_position

            # Real mode implementation
            roi = screen[
                self.minigame_region[1]:self.minigame_region[3],
                self.minigame_region[0]:self.minigame_region[2]
            ]

            gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
            _, thresh = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY)
            contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            if contours:
                largest_contour = max(contours, key=cv2.contourArea)
                x, y, w, h = cv2.boundingRect(largest_contour)
                relative_position = (x + w/2) / roi.shape[1]
                return relative_position

            return None
        except Exception as e:
            logger.error(f"Error detecting minigame bar: {e}")
            return None

    def set_minigame_region(self, x1: int, y1: int, x2: int, y2: int) -> None:
        """Set the region where the minigame appears"""
        try:
            self.minigame_region = (x1, y1, x2, y2)  # Fixed attribute name
            logger.info(f"Set minigame region to {self.minigame_region}")
        except Exception as e:
            logger.error(f"Error setting minigame region: {e}")