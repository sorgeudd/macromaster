import time
import random
import logging
import platform
import sys
import types
from pathfinding import PathFinder
from gameplay_learner import GameplayLearner
from typing import Optional, Tuple, List, Dict, Union

logger = logging.getLogger(__name__)

class GameController:
    def __init__(self):
        self.is_fishing = False
        self.in_minigame = False
        self.is_windows = platform.system() == 'Windows'
        self.test_mode = not self.is_windows
        self.screen_width = 1920  # Default screen width
        self.screen_height = 1080  # Default screen height
        self.safe_border = 50  # Keep mouse 50px from screen edges

        # Initialize gameplay learner
        self.learner = GameplayLearner()

        # Fishing state tracking
        self.last_cast_time: Optional[float] = None
        self.last_bite_time: Optional[float] = None
        self.last_hook_time: Optional[float] = None

        # Mount state
        self.is_mounted = False

        # Combat state
        self.in_combat = False
        self.skill_cooldowns: Dict[str, float] = {
            '2': 0.0,  # Skill 2 cooldown
            '3': 0.0,  # Skill 3 cooldown
            '4': 0.0   # Skill 4 cooldown
        }
        self.skill_base_cooldowns: Dict[str, float] = {
            '2': 8.0,  # Skill 2 base cooldown in seconds
            '3': 12.0, # Skill 3 base cooldown
            '4': 15.0  # Skill 4 cooldown
        }

        # Initialize pathfinder
        self.pathfinder = PathFinder(grid_size=32)
        self.current_path: List[Tuple[float, float]] = []
        self.movement_paused = False

        # Track current position in test mode
        self.current_x = self.screen_width / 2
        self.current_y = self.screen_height / 2

        if self.test_mode:
            logger.info("GameController initialized in test mode")
            self._setup_test_mode()
        else:
            try:
                import pyautogui
                # Disable PyAutoGUI's fail-safe but implement our own
                pyautogui.FAILSAFE = False
                self.screen_width, self.screen_height = pyautogui.size()
                logger.info(f"PyAutoGUI initialized with screen size: {self.screen_width}x{self.screen_height}")
            except Exception as e:
                logger.error(f"Failed to initialize PyAutoGUI: {e}")
                self.test_mode = True
                self._setup_test_mode()

    def toggle_mount(self):
        """Toggle mount state using button 1"""
        try:
            if self.test_mode:
                self.is_mounted = not self.is_mounted
                state = "mounted" if self.is_mounted else "dismounted"
                logger.info(f"Test mode: Character {state}")
                return True

            import pyautogui
            pyautogui.press('1')
            self.is_mounted = not self.is_mounted
            logger.info(f"Character {'mounted' if self.is_mounted else 'dismounted'}")
            return True
        except Exception as e:
            logger.error(f"Error toggling mount: {e}")
            return False

    def mount_at_location(self, x: float, y: float):
        """Mount at specific coordinates using left click"""
        try:
            if self.test_mode:
                logger.info(f"Test mode: Attempting to mount at ({x}, {y})")
                self.is_mounted = True
                return True

            if self.is_mounted:
                logger.debug("Already mounted, skipping mount action")
                return True

            # Move to mount location and click
            self.move_to_location(x, y)
            self.click(x, y)
            self.is_mounted = True
            logger.info(f"Mounted at location ({x}, {y})")
            return True
        except Exception as e:
            logger.error(f"Error mounting at location: {e}")
            return False

    def dismount_for_action(self):
        """Ensure character is dismounted for actions like combat or gathering"""
        if self.is_mounted:
            return self.toggle_mount()
        return True

    def use_combat_skill(self, skill_number: str):
        """Use combat skill if off cooldown"""
        try:
            current_time = time.time()

            # Check if skill is on cooldown
            if current_time < self.skill_cooldowns.get(skill_number, 0):
                logger.debug(f"Skill {skill_number} still on cooldown")
                return False

            if self.test_mode:
                logger.info(f"Test mode: Using combat skill {skill_number}")
                self.skill_cooldowns[skill_number] = current_time + self.skill_base_cooldowns[skill_number]
                return True

            # Ensure dismounted for combat
            if not self.dismount_for_action():
                return False

            import pyautogui
            pyautogui.press(skill_number)
            self.skill_cooldowns[skill_number] = current_time + self.skill_base_cooldowns[skill_number]
            logger.info(f"Used combat skill {skill_number}")
            return True
        except Exception as e:
            logger.error(f"Error using combat skill: {e}")
            return False

    def gather_resource(self, x: float, y: float):
        """Gather resource at location"""
        try:
            if self.test_mode:
                logger.info(f"Test mode: Gathering resource at ({x}, {y})")
                return True

            # Ensure dismounted for gathering
            if not self.dismount_for_action():
                return False

            # Move to resource location
            if not self.move_to_location(x, y):
                return False

            # Interact with resource
            self.click(x, y)
            logger.info(f"Gathered resource at ({x}, {y})")
            return True
        except Exception as e:
            logger.error(f"Error gathering resource: {e}")
            return False

    def _check_coordinates(self, x, y):
        """Enhanced coordinate validation with dynamic boundary handling"""
        try:
            # Add larger safety margin near screen edges
            safe_border = self.safe_border * 2.0  # Double the safety margin

            # Calculate safe boundaries with smooth transition zone
            edge_zone = safe_border * 0.5  # Transition zone near edges

            def smooth_boundary(val, min_val, max_val):
                if val < min_val + edge_zone:
                    # Smooth transition when approaching minimum boundary
                    factor = (val - min_val) / edge_zone
                    return min_val + (edge_zone * factor * factor)
                elif val > max_val - edge_zone:
                    # Smooth transition when approaching maximum boundary
                    factor = (max_val - val) / edge_zone
                    return max_val - (edge_zone * factor * factor)
                return val

            # Apply smooth boundary constraints
            safe_x = smooth_boundary(x, safe_border, self.screen_width - safe_border)
            safe_y = smooth_boundary(y, safe_border, self.screen_height - safe_border)

            # Add small random variation to prevent getting stuck
            if abs(safe_x - x) < 10 or abs(safe_y - y) < 10:
                safe_x += random.uniform(-5, 5)
                safe_y += random.uniform(-5, 5)

            # Final boundary check
            safe_x = max(safe_border, min(self.screen_width - safe_border, safe_x))
            safe_y = max(safe_border, min(self.screen_height - safe_border, safe_y))

            if safe_x != x or safe_y != y:
                logger.info(
                    f"Mouse position adjusted:\n"
                    f"Original: ({x:.1f}, {y:.1f})\n"
                    f"Adjusted: ({safe_x:.1f}, {safe_y:.1f})"
                )

            return safe_x, safe_y

        except Exception as e:
            logger.error(f"Error in coordinate validation: {e}")
            # Return center of screen as fallback
            return self.screen_width/2, self.screen_height/2

    def click(self, x, y, duration=0.0):
        """Perform mouse click at specific coordinates with boundary checking"""
        try:
            if self.test_mode:
                logger.debug(f"Test mode: Simulated click at ({x}, {y})")
                return True

            import pyautogui
            safe_x, safe_y = self._check_coordinates(x, y)

            # Move mouse with smooth motion
            pyautogui.moveTo(safe_x, safe_y, duration=0.2)

            if duration > 0:
                pyautogui.mouseDown()
                time.sleep(duration)
                pyautogui.mouseUp()
            else:
                pyautogui.click()

            logger.debug(f"Clicked at position ({safe_x}, {safe_y})")
            return True
        except Exception as e:
            logger.error(f"Error performing mouse click: {e}")
            return False

    def cast_line(self, x, y, power):
        """Cast fishing line with learning-adjusted power"""
        try:
            self.last_cast_time = time.time()

            if self.test_mode:
                logger.debug(f"Test mode: Cast line - Position: ({x:.1f}, {y:.1f}), Power: {power:.2f}")
                return True

            import pyautogui
            safe_x, safe_y = self._check_coordinates(x, y)

            # Apply learned timing adjustments
            optimal_power = power * random.uniform(0.95, 1.05)  # Add slight variation

            pyautogui.moveTo(safe_x, safe_y, duration=0.2)
            pyautogui.mouseDown()
            time.sleep(optimal_power)
            pyautogui.mouseUp()

            logger.info(f"Cast line at ({safe_x}, {safe_y}) with power {optimal_power}")
            return True
        except Exception as e:
            logger.error(f"Error casting fishing line: {e}")
            return False

    def handle_fish_bite(self):
        """Record bite timing and calculate optimal hook timing"""
        self.last_bite_time = time.time()
        if self.last_cast_time:
            cast_to_bite = self.last_bite_time - self.last_cast_time
            logger.info(f"Fish bite detected after {cast_to_bite:.2f} seconds")

            # Get optimal timing from learner
            optimal_timing = self.learner.get_optimal_hook_timing()
            time.sleep(optimal_timing)

            # Attempt hook
            self.last_hook_time = time.time()
            if not self.test_mode:
                import pyautogui
                pyautogui.click()

            # Record attempt
            self.learner.record_fishing_attempt(
                self.last_cast_time,
                self.last_bite_time,
                self.last_hook_time,
                True  # Success will be updated based on minigame outcome
            )

    def handle_minigame(self, bar_position):
        """Handle the fishing minigame with learned behavior"""
        if not self.in_minigame:
            return False

        try:
            # Get optimal click threshold from learner
            optimal_threshold = self.learner.get_optimal_click_threshold()

            if self.test_mode:
                action = "waiting"
                if bar_position < optimal_threshold:
                    action = "clicking"
                logger.debug(f"Test mode: Minigame - Action: {action}, Bar: {bar_position:.2f}")
                return True

            import pyautogui
            if bar_position < optimal_threshold:
                pyautogui.click()
                self.learner.record_minigame_action(bar_position, time.time(), True)
            else:
                time.sleep(0.1)

            return True
        except Exception as e:
            logger.error(f"Error handling minigame: {e}")
            return False

    def record_spot_transition(self, from_spot, to_spot, duration):
        """Record movement between fishing spots"""
        self.learner.record_spot_transition(from_spot, to_spot, duration)

    def get_learning_stats(self):
        """Get current learning statistics"""
        return self.learner.get_learning_stats()

    def move_to_location(self, target_x: float, target_y: float, avoid_obstacles: bool = True) -> bool:
        """Enhanced movement with pathfinding support"""
        try:
            if self.test_mode:
                logger.debug(f"Test mode: Moving to location ({target_x}, {target_y})")
                # Calculate path from current test position
                path = self.pathfinder.calculate_path(
                    self.current_x, self.current_y, target_x, target_y
                )
                if not path:
                    logger.warning("No valid path found to target")
                    return False

                # Update current position in test mode
                self.current_x = target_x
                self.current_y = target_y
                logger.info(f"Test mode: Moved to ({self.current_x}, {self.current_y})")
                return True

            # Real mode implementation
            import pyautogui
            current_x, current_y = pyautogui.position()

            # Calculate path
            path = self.pathfinder.calculate_path(current_x, current_y, target_x, target_y)
            if not path:
                logger.warning("No valid path found to target")
                return False

            # Smooth the path
            smoothed_path = self.pathfinder.smooth_path(path)
            self.current_path = smoothed_path

            # Follow the path
            for x, y in smoothed_path:
                if self.movement_paused:
                    logger.info("Movement paused")
                    return False

                safe_x, safe_y = self._check_coordinates(x, y)
                pyautogui.moveTo(safe_x, safe_y, duration=0.2)
                time.sleep(0.1)  # Small delay between movements

            logger.info(f"Reached target location ({target_x}, {target_y})")
            return True

        except Exception as e:
            logger.error(f"Error moving to location: {e}")
            return False

    def pause_movement(self):
        """Pause any ongoing movement"""
        self.movement_paused = True
        logger.info("Movement paused")

    def resume_movement(self):
        """Resume movement if paused"""
        self.movement_paused = False
        logger.info("Movement resumed")

    def add_obstacle(self, x: float, y: float):
        """Add an obstacle for pathfinding"""
        self.pathfinder.add_obstacle(x, y)

    def clear_obstacles(self):
        """Clear all registered obstacles"""
        self.pathfinder.clear_obstacles()


    def _setup_test_mode(self):
        """
        Set up test mode with mock PyAutoGUI functionality.

        Test Mode Features:
        - Mocked mouse and keyboard interactions
        - Logging of all simulated actions
        - Safe execution environment
        """
        try:
            mock_module = types.ModuleType('pyautogui')

            def mock_function(*args, **kwargs):
                caller_name = sys._getframe().f_back.f_code.co_name if sys._getframe().f_back else "unknown"
                logger.debug(f"Mock PyAutoGUI: {caller_name} called with args={args}, kwargs={kwargs}")
                return None

            mock_attrs = {
                'FAILSAFE': True,
                'click': mock_function,
                'moveTo': mock_function,
                'mouseDown': mock_function,
                'mouseUp': mock_function,
                'press': mock_function,
                'size': lambda: (self.screen_width, self.screen_height),
                'position': lambda: (self.current_x, self.current_y)
            }

            for attr, value in mock_attrs.items():
                setattr(mock_module, attr, value)

            sys.modules['pyautogui'] = mock_module
            logger.info("Test mode: PyAutoGUI mock initialized")
        except Exception as e:
            logger.error(f"Error setting up test mode: {e}")

    def combat_action(self, skill_key):
        """Perform combat action"""
        try:
            if self.test_mode:
                logger.debug(f"Test mode: Simulated combat action with key {skill_key}")
                return True

            import pyautogui
            pyautogui.press(skill_key)
            time.sleep(0.1)

            logger.debug(f"Performed combat action with key {skill_key}")
            return True
        except Exception as e:
            logger.error(f"Error performing combat action: {e}")
            return False