import json
import logging
import numpy as np
import time
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Union
import os
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from ai_inference import AIInference

logger = logging.getLogger(__name__)

class GameplayLearner:
    def __init__(self):
        self.learning_data_path = "learned_patterns.json"
        self.current_session: List[Dict] = []
        self.learned_patterns: Dict[str, Dict] = {
            'timing': {
                'cast_to_bite': [],
                'bite_to_hook': [],
                'success_rate': 0.0
            },
            'movement': {
                'spot_transitions': [],
                'spot_durations': []
            },
            'minigame': {
                'click_timings': [],
                'success_thresholds': []
            }
        }

        # Initialize ML models
        logger.info("Initializing machine learning models")
        self.timing_model = RandomForestRegressor(n_estimators=50, random_state=42)
        self.success_predictor = RandomForestRegressor(n_estimators=50, random_state=42)
        self.scaler = StandardScaler()

        # Initialize AI inference
        logger.info("Initializing AI inference system")
        self.ai_inference = AIInference()

        # Load existing data
        self.load_learned_patterns()

    def get_optimal_click_threshold(self) -> float:
        """Get optimal threshold for clicking during minigame with AI enhancement"""
        try:
            # Get AI analysis of current patterns
            logger.info("Getting AI analysis for click threshold optimization")
            ai_analysis = self.ai_inference.analyze_gameplay_pattern(self.learned_patterns)

            if len(self.learned_patterns['minigame']['click_timings']) > 10:
                recent_timings = np.array(self.learned_patterns['minigame']['click_timings'][-20:])
                base_threshold = float(np.median(recent_timings))
                logger.info(f"Base threshold from recent timings: {base_threshold:.3f}")

                # Adjust threshold based on AI confidence
                ai_adjustment = ai_analysis['optimal_timing'] - 0.5  # Center around 0
                final_threshold = base_threshold + (ai_adjustment * 0.2)  # Apply 20% AI influence
                logger.info(f"AI-adjusted threshold: {final_threshold:.3f} (adjustment: {ai_adjustment:.3f})")

                return max(0.1, min(0.9, final_threshold))

            logger.info("Insufficient data, using default threshold")
            return 0.5  # Default threshold
        except Exception as e:
            logger.error(f"Error getting optimal click threshold: {e}")
            return 0.5

    def record_minigame_action(self, position: float, timing: float, success: bool) -> None:
        """Record a minigame action"""
        try:
            logger.info(f"Recording minigame action - Position: {position:.3f}, Timing: {timing:.3f}, Success: {success}")
            self.learned_patterns['minigame']['click_timings'].append(float(timing))
            self.learned_patterns['minigame']['success_thresholds'].append(float(position))

            # Keep only recent data
            max_samples = 100
            self.learned_patterns['minigame']['click_timings'] = \
                self.learned_patterns['minigame']['click_timings'][-max_samples:]
            self.learned_patterns['minigame']['success_thresholds'] = \
                self.learned_patterns['minigame']['success_thresholds'][-max_samples:]

            logger.info(f"Total recorded minigame actions: {len(self.learned_patterns['minigame']['click_timings'])}")
        except Exception as e:
            logger.error(f"Error recording minigame action: {e}")

    def load_learned_patterns(self):
        """Load previously learned patterns from file"""
        try:
            if os.path.exists(self.learning_data_path):
                with open(self.learning_data_path, 'r') as f:
                    self.learned_patterns = json.load(f)
                logger.info("Loaded learned patterns from file")

                # Train models if enough data exists
                self._train_models()
        except Exception as e:
            logger.error(f"Error loading learned patterns: {e}")

    def _train_models(self):
        """Train ML models with existing data"""
        try:
            # Prepare timing data
            if len(self.learned_patterns['timing']['cast_to_bite']) > 10:
                X_timing = np.array(self.learned_patterns['timing']['cast_to_bite']).reshape(-1, 1)
                y_timing = np.array(self.learned_patterns['timing']['bite_to_hook'])

                # Scale features
                self.scaler.fit(X_timing)
                X_timing_scaled = self.scaler.transform(X_timing)

                # Train timing model
                self.timing_model.fit(X_timing_scaled, y_timing)
                logger.info("Trained timing prediction model")

            # Prepare success prediction data
            if len(self.learned_patterns['minigame']['click_timings']) > 10:
                X_success = np.array(self.learned_patterns['minigame']['click_timings']).reshape(-1, 1)
                y_success = np.array([float(t > 0) for t in self.learned_patterns['minigame']['success_thresholds']])

                # Train success predictor
                self.success_predictor.fit(X_success, y_success)
                logger.info("Trained success prediction model")

        except Exception as e:
            logger.error(f"Error training models: {e}")

    def predict_optimal_timing(self, cast_time: float) -> float:
        """Predict optimal timing using ML predictions with AI enhancement"""
        try:
            logger.info(f"Predicting optimal timing for cast time: {cast_time:.3f}")
            if len(self.learned_patterns['timing']['cast_to_bite']) > 10:
                # Get base prediction from ML model
                try:
                    X_pred = np.array([[cast_time]]).reshape(1, -1)
                    X_pred_scaled = self.scaler.transform(X_pred)
                    base_prediction = self.timing_model.predict(X_pred_scaled)[0]
                    logger.info(f"ML model base prediction: {base_prediction:.3f}")
                except Exception as e:
                    logger.warning(f"ML prediction failed, using fallback: {e}")
                    base_prediction = 0.5

                # Get AI analysis
                ai_analysis = self.ai_inference.analyze_gameplay_pattern(self.learned_patterns)
                logger.info(f"AI analysis results: {ai_analysis}")

                # Blend predictions based on AI confidence
                ai_weight = ai_analysis['pattern_reliability']
                ml_weight = 1 - ai_weight
                logger.info(f"Blending weights - AI: {ai_weight:.2f}, ML: {ml_weight:.2f}")

                final_prediction = (base_prediction * ml_weight + 
                                ai_analysis['optimal_timing'] * ai_weight)
                logger.info(f"Final blended prediction: {final_prediction:.3f}")

                return max(0.1, min(2.0, final_prediction))

            logger.info("Insufficient data for ML prediction, using default timing")
            return 0.5  # Default if not enough data
        except Exception as e:
            logger.error(f"Error predicting optimal timing: {e}")
            return 0.5

    def predict_success_probability(self, timing: float) -> float:
        """Predict success probability for given timing"""
        try:
            if len(self.learned_patterns['minigame']['click_timings']) > 10:
                X_pred = np.array([[timing]]).reshape(1, -1)
                # Use predict() to get a probability-like score between 0 and 1
                return float(self.success_predictor.predict(X_pred)[0])
            return 0.5  # Default if not enough data
        except Exception as e:
            logger.error(f"Error predicting success probability: {e}")
            return 0.5

    def record_fishing_attempt(self, cast_time: float, bite_time: float, hook_time: float, success: bool):
        """Record timing data from a fishing attempt with ML update"""
        try:
            logger.info(f"Recording fishing attempt - Cast: {cast_time:.2f}, Bite: {bite_time:.2f}, Hook: {hook_time:.2f}")
            cast_to_bite = bite_time - cast_time
            bite_to_hook = hook_time - bite_time

            self.learned_patterns['timing']['cast_to_bite'].append(cast_to_bite)
            self.learned_patterns['timing']['bite_to_hook'].append(bite_to_hook)

            # Keep only recent attempts (last 50)
            max_samples = 50
            self.learned_patterns['timing']['cast_to_bite'] = self.learned_patterns['timing']['cast_to_bite'][-max_samples:]
            self.learned_patterns['timing']['bite_to_hook'] = self.learned_patterns['timing']['bite_to_hook'][-max_samples:]

            # Update success rate
            total_attempts = len(self.learned_patterns['timing']['cast_to_bite'])
            success_count = sum(1 for x in self.learned_patterns['timing']['bite_to_hook'] if x > 0)
            self.learned_patterns['timing']['success_rate'] = success_count / total_attempts if total_attempts > 0 else 0

            logger.info(f"Updated success rate: {self.learned_patterns['timing']['success_rate']:.2%}")

            # Retrain models if enough new data
            if len(self.learned_patterns['timing']['cast_to_bite']) % 5 == 0:
                logger.info("Retraining ML models with updated data")
                self._train_models()

            self.save_learned_patterns()

        except Exception as e:
            logger.error(f"Error recording fishing attempt: {e}")

    def record_spot_transition(self, from_spot: Tuple[int, int], to_spot: Tuple[int, int], duration: float):
        """Record movement between fishing spots with enhanced analysis"""
        try:
            transition = {
                'from': list(from_spot),
                'to': list(to_spot),
                'duration': duration,
                'success_rate': self.learned_patterns['timing']['success_rate']
            }
            self.learned_patterns['movement']['spot_transitions'].append(transition)
            self.learned_patterns['movement']['spot_transitions'] = \
                self.learned_patterns['movement']['spot_transitions'][-50:]  # Keep last 50

            logger.info(f"Recorded spot transition: {from_spot} -> {to_spot} ({duration:.2f}s)")
            self.save_learned_patterns()

        except Exception as e:
            logger.error(f"Error recording spot transition: {e}")

    def get_optimal_hook_timing(self) -> float:
        """Calculate optimal timing using ML predictions"""
        try:
            if not self.learned_patterns['timing']['bite_to_hook']:
                return 0.5  # Default timing if no data

            # Use ML prediction if available
            if len(self.learned_patterns['timing']['cast_to_bite']) > 10:
                recent_cast_time = self.learned_patterns['timing']['cast_to_bite'][-1]
                return self.predict_optimal_timing(recent_cast_time)

            # Fallback to simple average if not enough data
            successful_timings = [t for t in self.learned_patterns['timing']['bite_to_hook']
                                 if 0.1 <= t <= 2.0]

            if not successful_timings:
                return 0.5

            optimal_timing = np.mean(successful_timings)
            return min(max(optimal_timing, 0.1), 2.0)

        except Exception as e:
            logger.error(f"Error calculating optimal hook timing: {e}")
            return 0.5

    def save_learned_patterns(self):
        """Save learned patterns to file"""
        try:
            with open(self.learning_data_path, 'w') as f:
                json.dump(self.learned_patterns, f, indent=4)
            logger.info("Saved learned patterns to file")
        except Exception as e:
            logger.error(f"Error saving learned patterns: {e}")

    def get_learning_stats(self) -> Dict:
        """Get current learning statistics with ML insights"""
        try:
            stats = {
                'total_attempts': len(self.learned_patterns['timing']['cast_to_bite']),
                'success_rate': self.learned_patterns['timing']['success_rate'],
                'optimal_hook_timing': self.get_optimal_hook_timing(),
                'ml_model_trained': len(self.learned_patterns['timing']['cast_to_bite']) > 10
            }

            if stats['ml_model_trained']:
                stats['predicted_success_rate'] = self.predict_success_probability(stats['optimal_hook_timing'])

            logger.info(f"Current learning stats: {stats}")
            return stats
        except Exception as e:
            logger.error(f"Error getting learning stats: {e}")
            return {
                'total_attempts': 0,
                'success_rate': 0.0,
                'optimal_hook_timing': 0.5,
                'ml_model_trained': False
            }